import subprocess,sys,json
from pathlib import Path
from datetime import datetime,timezone

steps=[
 ("e2e",[sys.executable,"scripts/r10/run_end_to_end_validation.py"]),
 ("public_smoke",[sys.executable,"scripts/r10/public_smoke_suite.py"]),
 ("cutover_readiness",[sys.executable,"scripts/r10/cutover_readiness_gate.py"]),
 ("post_cutover",[sys.executable,"scripts/r10/post_cutover_gate.py"]),
 ("final_production_verification",[sys.executable,"scripts/r10/final_production_verification_gate.py"])
]
results={};failed=[]
for name,cmd in steps:
    p=subprocess.run(cmd,text=True,capture_output=True)
    results[name]={"exit_code":p.returncode,"stdout":p.stdout[-8000:],"stderr":p.stderr[-3000:]}
    if p.returncode: failed.append(name)

state="PRIMELINK_REBUILD_PRODUCTION_VERIFIED" if not failed else "R10_VALIDATION_OR_CUTOVER_BLOCKED"
report={"executed_at":datetime.now(timezone.utc).isoformat(),"state":state,"failed_steps":failed,"results":results}
Path("reports/r10").mkdir(parents=True,exist_ok=True)
Path("reports/r10/master_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not failed else 2)
