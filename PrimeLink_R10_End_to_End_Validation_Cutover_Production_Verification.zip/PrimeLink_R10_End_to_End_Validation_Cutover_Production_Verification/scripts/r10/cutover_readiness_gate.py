import csv,json,sys
from pathlib import Path

rows=list(csv.DictReader(Path("evidence/r10/CUTOVER_READINESS.csv").open()))
critical=[r for r in rows if r.get("critical","").lower()=="true"]
bad=[r for r in critical if r.get("status")!="PASS"]
report={
 "critical_checks":len(critical),
 "blocking":[{"check_id":r.get("check_id"),"check":r.get("check"),"status":r.get("status")} for r in bad],
 "state":"R10_CUTOVER_READY" if not bad else "R10_CUTOVER_BLOCKED"
}
Path("reports/r10").mkdir(parents=True,exist_ok=True)
Path("reports/r10/cutover_readiness_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not bad else 2)
