import csv,json,sys
from pathlib import Path

rows=list(csv.DictReader(Path("evidence/r10/FINAL_PRODUCTION_GATES.csv").open()))
critical=[r for r in rows if r.get("critical","").lower()=="true"]
bad=[r for r in critical if r.get("status")!="PASS"]

owners=Path("evidence/r10/PRODUCTION_OWNERS.csv")
owner_rows=list(csv.DictReader(owners.open())) if owners.exists() else []
owner_bad=[r for r in owner_rows if r.get("required","").lower()=="true" and (not r.get("name") or r.get("accepted","").lower()!="true")]

report={
 "critical_gates":len(critical),
 "blocking_gates":[{"gate_id":r.get("gate_id"),"gate":r.get("gate"),"status":r.get("status")} for r in bad],
 "owner_blockers":[r.get("role") for r in owner_bad],
}
ok=not bad and not owner_bad
report["state"]="PRIMELINK_REBUILD_PRODUCTION_VERIFIED" if ok else "R10_PRODUCTION_VERIFICATION_BLOCKED"

Path("reports/r10").mkdir(parents=True,exist_ok=True)
Path("reports/r10/final_production_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if ok else 2)
