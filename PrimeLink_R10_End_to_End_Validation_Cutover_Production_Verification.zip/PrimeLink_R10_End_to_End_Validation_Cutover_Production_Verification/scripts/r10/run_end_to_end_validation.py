import subprocess, sys, json
from pathlib import Path
from datetime import datetime, timezone

steps = [
    ("R2_schema","scripts/r2/verify_database_schema.py"),
    ("R2_migration_head","scripts/r2/verify_migration_head.py"),
    ("R3_security_runtime","scripts/r3/verify_security_runtime.py"),
    ("R4_business_core","scripts/r4/verify_business_core.py"),
    ("R5_matching_engine","scripts/r5/verify_matching_engine.py"),
    ("R6_connector_contract","scripts/r6/verify_connector_contract.py"),
    ("R6_provenance","scripts/r6/verify_discovery_provenance.py"),
    ("R7_commercial_engine","scripts/r7/verify_commercial_engine.py"),
    ("R7_commercial_registers","scripts/r7/verify_commercial_registers.py"),
    ("R8_control_plane","scripts/r8/verify_control_plane.py"),
    ("R8_operational_evidence","scripts/r8/operational_evidence_gate.py"),
    ("R9_environment","scripts/r9/verify_environment.py")
]

results={}; failed=[]; missing=[]
for name,path in steps:
    p=Path(path)
    if not p.exists():
        missing.append(name)
        continue
    try:
        r=subprocess.run([sys.executable,path],text=True,capture_output=True,timeout=60)
        results[name]={"exit_code":r.returncode,"stdout":r.stdout[-6000:],"stderr":r.stderr[-3000:]}
        if r.returncode:
            failed.append(name)
    except subprocess.TimeoutExpired:
        results[name]={"exit_code":124,"error":"TIMEOUT"}
        failed.append(name)

state="R10_E2E_PASS" if not failed and not missing else "R10_E2E_REMEDIATION_REQUIRED"
report={
    "executed_at":datetime.now(timezone.utc).isoformat(),
    "state":state,
    "failed_steps":failed,
    "missing_steps":missing,
    "results":results
}
Path("reports/r10").mkdir(parents=True,exist_ok=True)
Path("reports/r10/e2e_validation.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if state=="R10_E2E_PASS" else 2)
