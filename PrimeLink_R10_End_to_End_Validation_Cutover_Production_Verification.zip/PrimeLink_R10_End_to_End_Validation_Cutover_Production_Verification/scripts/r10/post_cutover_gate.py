import csv,json,sys
from pathlib import Path
rows=list(csv.DictReader(Path("evidence/r10/POST_CUTOVER_OBSERVATION.csv").open()))
critical=[r for r in rows if r.get("critical","").lower()=="true"]
bad=[r for r in critical if r.get("status")!="PASS"]
report={
 "observations":len(rows),
 "blocking":[{"observation_id":r.get("observation_id"),"metric_or_check":r.get("metric_or_check"),"status":r.get("status")} for r in bad],
 "state":"R10_POST_CUTOVER_PASS" if not bad else "R10_POST_CUTOVER_BLOCK"
}
Path("reports/r10").mkdir(parents=True,exist_ok=True)
Path("reports/r10/post_cutover_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not bad else 2)
