import csv,json,sys
from pathlib import Path
rows=list(csv.DictReader(Path("evidence/r9/RELEASE_GATES.csv").open()))
critical=[r for r in rows if r.get("critical","").lower()=="true"]
bad=[r for r in critical if r.get("status")!="PASS"]
report={
 "critical_total":len(critical),
 "blocking":[{"gate_id":r.get("gate_id"),"gate":r.get("gate"),"status":r.get("status")} for r in bad],
 "state":"R9_RELEASE_APPROVED" if not bad else "R9_RELEASE_HELD"
}
Path("reports/r9").mkdir(parents=True,exist_ok=True)
Path("reports/r9/release_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not bad else 2)
