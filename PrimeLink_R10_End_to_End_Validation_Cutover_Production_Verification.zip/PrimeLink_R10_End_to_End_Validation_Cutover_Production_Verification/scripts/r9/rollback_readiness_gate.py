import csv,json,sys
from pathlib import Path
rows=list(csv.DictReader(Path("evidence/r9/ROLLBACK_READINESS.csv").open()))
ready=[r for r in rows if r.get("status")=="PASS" and r.get("rollback_method") and r.get("owner")]
report={"records":len(rows),"ready_records":len(ready),"state":"PASS" if ready else "BLOCK"}
Path("reports/r9").mkdir(parents=True,exist_ok=True)
Path("reports/r9/rollback_readiness_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if ready else 2)
