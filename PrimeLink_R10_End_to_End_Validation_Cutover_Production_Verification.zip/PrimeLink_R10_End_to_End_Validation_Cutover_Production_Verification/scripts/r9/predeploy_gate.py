import subprocess,sys,json
from datetime import datetime,timezone
from pathlib import Path

steps=[
 ("environment",[sys.executable,"scripts/r9/verify_environment.py"]),
 ("migrations",[sys.executable,"scripts/r2/run_migrations.py"]),
]
results={};failed=[]
for name,cmd in steps:
    p=subprocess.run(cmd,text=True,capture_output=True)
    results[name]={"exit_code":p.returncode,"stdout":p.stdout[-8000:],"stderr":p.stderr[-4000:]}
    if p.returncode: failed.append(name)

report={
 "executed_at":datetime.now(timezone.utc).isoformat(),
 "state":"R9_PREDEPLOY_PASS" if not failed else "R9_PREDEPLOY_BLOCK",
 "failed_steps":failed,
 "results":results
}
Path("reports/r9").mkdir(parents=True,exist_ok=True)
Path("reports/r9/predeploy_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not failed else 2)
