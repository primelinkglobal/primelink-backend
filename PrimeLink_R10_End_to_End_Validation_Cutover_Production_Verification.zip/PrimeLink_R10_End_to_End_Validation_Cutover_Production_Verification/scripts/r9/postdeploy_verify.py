import os,json,sys,urllib.request,urllib.error
from pathlib import Path
from datetime import datetime,timezone

base=os.getenv("DEPLOYED_BASE_URL") or os.getenv("PUBLIC_BASE_URL") or ""
paths=["/health/live","/health/ready","/runtime","/business-core","/intelligence","/discovery-runtime","/commercial-runtime","/control-plane"]
results={};failed=[]
for path in paths:
    url=base.rstrip("/") + path
    try:
        req=urllib.request.Request(url,headers={"User-Agent":"PrimeLink-R9/1.0"})
        with urllib.request.urlopen(req,timeout=15) as r:
            body=r.read(1000).decode("utf-8","ignore")
            results[path]={"status":r.status,"body_preview":body[:500]}
            if r.status != 200: failed.append(path)
    except Exception as e:
        results[path]={"error_type":type(e).__name__}
        failed.append(path)

report={
 "executed_at":datetime.now(timezone.utc).isoformat(),
 "base_url":base,
 "state":"R9_POSTDEPLOY_PASS" if not failed else "R9_POSTDEPLOY_BLOCK",
 "failed_paths":failed,
 "results":results
}
Path("reports/r9").mkdir(parents=True,exist_ok=True)
Path("reports/r9/postdeploy_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not failed else 2)
