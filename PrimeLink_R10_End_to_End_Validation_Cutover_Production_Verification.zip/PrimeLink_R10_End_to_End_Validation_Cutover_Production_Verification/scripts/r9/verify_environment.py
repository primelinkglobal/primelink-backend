import os,json,sys
from pathlib import Path

truth=lambda v:str(v).lower() in ("1","true","yes","on")
db=os.getenv("DATABASE_URL","")
checks={
 "app_env_production":os.getenv("APP_ENV","").lower()=="production",
 "app_version_present":bool(os.getenv("APP_VERSION","").strip()),
 "database_url_postgresql":db.lower().startswith(("postgresql://","postgresql+psycopg://","postgres://")),
 "jwt_secret_min_32_bytes":len(os.getenv("JWT_SECRET","").encode())>=32,
 "bootstrap_admin_disabled":not truth(os.getenv("ALLOW_BOOTSTRAP_ADMIN","false")),
 "public_base_url_https":os.getenv("PUBLIC_BASE_URL","").startswith("https://"),
 "cors_explicit":"*" not in [x.strip() for x in os.getenv("CORS_ORIGINS","").split(",") if x.strip()],
 "trusted_hosts_present":bool(os.getenv("TRUSTED_HOSTS","").strip()),
 "secure_cookies":truth(os.getenv("SECURE_COOKIES","true")),
 "proxy_headers":truth(os.getenv("TRUST_PROXY_HEADERS","true")),
 "automatic_introductions_disabled":not truth(os.getenv("AUTOMATIC_INTRODUCTIONS_ENABLED","false"))
}
report={"state":"PASS" if all(checks.values()) else "BLOCK","checks":checks,"note":"Secret values intentionally omitted."}
Path("reports/r9").mkdir(parents=True,exist_ok=True)
Path("reports/r9/environment_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if all(checks.values()) else 2)
