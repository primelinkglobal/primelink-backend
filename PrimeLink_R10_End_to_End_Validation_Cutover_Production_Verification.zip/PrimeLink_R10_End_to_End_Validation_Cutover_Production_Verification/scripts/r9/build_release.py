import subprocess, sys, json
from datetime import datetime, timezone
from pathlib import Path

steps=[
    ("install_dependencies",[sys.executable,"-m","pip","install","-r","requirements.txt"]),
]
results={}; failed=[]
for name,cmd in steps:
    p=subprocess.run(cmd,text=True,capture_output=True)
    results[name]={"exit_code":p.returncode,"stdout":p.stdout[-5000:],"stderr":p.stderr[-5000:]}
    if p.returncode: failed.append(name)

report={
    "executed_at":datetime.now(timezone.utc).isoformat(),
    "state":"R9_BUILD_READY" if not failed else "R9_BUILD_FAILED",
    "failed_steps":failed,
    "results":results
}
Path("reports/r9").mkdir(parents=True,exist_ok=True)
Path("reports/r9/build_release.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not failed else 2)
