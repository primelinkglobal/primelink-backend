import json,sys
from pathlib import Path
from app.core.commercial_engine import compute_percentage_fee, invoice_eligible, reconciliation_state

earned=compute_percentage_fee("2500000","1.5","USD","executed",True).to_dict()
potential=compute_percentage_fee("2500000","1.5","USD","draft",True).to_dict()
checks={
 "decimal_fee_correct":earned["fee_amount"]=="37500.00",
 "currency_preserved":earned["currency"]=="USD",
 "executed_trigger_can_be_earned":earned["state"]=="earned",
 "draft_agreement_not_earned":potential["state"]=="potential",
 "earned_approved_invoice_eligible":invoice_eligible("earned",True) is True,
 "unapproved_not_invoice_eligible":invoice_eligible("earned",False) is False,
 "exact_receipt_matches":reconciliation_state("37500","37500")=="matched",
 "mismatched_receipt_exception":reconciliation_state("37500","30000")=="exception"
}
report={"state":"PASS" if all(checks.values()) else "FAIL","checks":checks,"sample_earned_fee":earned}
Path("reports/r7").mkdir(parents=True,exist_ok=True)
Path("reports/r7/commercial_engine_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if all(checks.values()) else 2)
