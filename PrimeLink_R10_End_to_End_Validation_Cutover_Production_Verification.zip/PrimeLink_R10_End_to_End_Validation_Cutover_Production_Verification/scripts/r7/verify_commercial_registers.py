import csv,json,sys
from pathlib import Path

specs={
 "fee_events":("evidence/r7/FEE_EVENTS.csv",["fee_event_id","commercial_basis_id","currency","status"]),
 "invoices":("evidence/r7/INVOICES.csv",["invoice_id","invoice_number","currency","status"]),
 "collections":("evidence/r7/COLLECTIONS.csv",["collection_id","invoice_id","currency","status"])
}
issues=[];counts={}
for name,(path,required) in specs.items():
 p=Path(path);rows=list(csv.DictReader(p.open())) if p.exists() else []
 counts[name]=len(rows)
 for i,r in enumerate(rows,2):
  for key in required:
   if not (r.get(key) or "").strip():
    issues.append({"register":name,"row":i,"issue":"missing_"+key})

# duplicate controls
p=Path("evidence/r7/INVOICES.csv")
rows=list(csv.DictReader(p.open())) if p.exists() else []
nums=[r.get("invoice_number") for r in rows if r.get("invoice_number")]
dups=sorted({x for x in nums if nums.count(x)>1})
if dups: issues.append({"register":"invoices","issue":"duplicate_invoice_number","values":dups})

report={"counts":counts,"issues":issues,"state":"PASS" if not issues else "REMEDIATION_REQUIRED"}
Path("reports/r7").mkdir(parents=True,exist_ok=True)
Path("reports/r7/commercial_register_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not issues else 2)
