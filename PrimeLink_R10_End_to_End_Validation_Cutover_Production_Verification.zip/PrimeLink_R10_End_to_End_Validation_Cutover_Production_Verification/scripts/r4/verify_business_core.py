import json, re, sys
from pathlib import Path

route_terms=("participant","investor","mandate","partner","opportun","crm","relationship","workflow","introduction")
routes=[]
for p in sorted(Path("app").rglob("*.py")):
    txt=p.read_text(errors="ignore")
    for i,line in enumerate(txt.splitlines(),1):
        if "@" in line and any(t in line.lower() for t in route_terms):
            routes.append({"source":str(p),"line":i,"definition":line.strip()[:240]})

tables=[]
for p in sorted(Path("app").rglob("*.py")):
    txt=p.read_text(errors="ignore")
    for m in re.finditer(r'__tablename__\s*=\s*["\']([^"\']+)["\']',txt):
        if any(t in m.group(1).lower() for t in route_terms):
            tables.append({"table":m.group(1),"source":str(p)})

report={
    "state":"R4_BUSINESS_CORE_INVENTORIED",
    "route_signal_count":len(routes),
    "table_signal_count":len(tables),
    "routes":routes,
    "tables":tables
}
Path("reports/r4").mkdir(parents=True,exist_ok=True)
Path("reports/r4/business_core_inventory.json").write_text(json.dumps(report,indent=2))
print(json.dumps({"state":report["state"],"route_signal_count":len(routes),"table_signal_count":len(tables)},indent=2))
