import csv, json, sys
from pathlib import Path

files = {
  "investor_mandates":"evidence/r4/INVESTOR_MANDATES.csv",
  "opportunities":"evidence/r4/OPPORTUNITIES.csv",
  "partners":"evidence/r4/PARTNERS.csv"
}
issues=[]
counts={}
for domain,path in files.items():
    p=Path(path)
    if not p.exists():
        issues.append({"domain":domain,"issue":"register_missing"})
        continue
    rows=list(csv.DictReader(p.open()))
    counts[domain]=len(rows)
    for idx,r in enumerate(rows,2):
        for key in ("record_id","owner","status","source"):
            if not (r.get(key) or "").strip():
                issues.append({"domain":domain,"row":idx,"issue":f"missing_{key}"})

report={"counts":counts,"issues":issues,"state":"PASS" if not issues else "REMEDIATION_REQUIRED"}
Path("reports/r4").mkdir(parents=True,exist_ok=True)
Path("reports/r4/record_quality.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not issues else 2)
