import json, sys
from pathlib import Path
from app.core.matching_engine import score_match

mandate={
 "geography":["dubai","abu dhabi"],
 "sector_or_asset_type":["real estate"],
 "ticket_min":1000000,
 "ticket_max":5000000,
 "liquidity_horizon":"medium",
 "risk_profile":"moderate",
 "transaction_type":"equity",
 "verification_state":"verified",
 "status":"active"
}
opportunity={
 "geography":"dubai",
 "sector_or_asset_type":"real estate",
 "value_or_size":2500000,
 "liquidity_horizon":"medium",
 "risk_profile":"moderate",
 "transaction_type":"equity",
 "verification_state":"verified",
 "status":"active"
}
result=score_match(mandate,opportunity,relationship_context=70).to_dict()
checks={
 "score_in_range":0 <= result["overall_score"] <= 100,
 "human_review_required":result["review_requirement"] in {"human_review_required","priority_human_review"},
 "explanation_present":bool(result["positive_factors"]),
 "verification_preserved":result["verification_state"]=="verified_inputs",
 "automatic_introduction_not_authorized":"introduction" not in result["review_requirement"].lower()
}
report={"state":"PASS" if all(checks.values()) else "FAIL","checks":checks,"sample_result":result}
Path("reports/r5").mkdir(parents=True,exist_ok=True)
Path("reports/r5/matching_engine_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if all(checks.values()) else 2)
