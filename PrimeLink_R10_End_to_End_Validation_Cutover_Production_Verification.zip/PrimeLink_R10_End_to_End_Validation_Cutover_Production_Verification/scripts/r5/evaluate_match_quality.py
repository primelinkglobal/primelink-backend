import csv,json,sys
from pathlib import Path

p=Path("evidence/r5/MATCH_REVIEW_OUTCOMES.csv")
rows=list(csv.DictReader(p.open())) if p.exists() else []
total=len(rows)
approved=sum(1 for r in rows if r.get("human_decision")=="approved")
rejected=sum(1 for r in rows if r.get("human_decision")=="rejected")
overrides=sum(1 for r in rows if r.get("engine_recommendation") and r.get("human_decision") and r.get("engine_recommendation")!=r.get("human_decision"))
report={
 "reviewed_matches":total,
 "approved":approved,
 "rejected":rejected,
 "override_rate":round(overrides/total,4) if total else None,
 "state":"NO_LIVE_REVIEW_DATA" if not total else "R5_MATCH_QUALITY_MEASURED"
}
Path("reports/r5").mkdir(parents=True,exist_ok=True)
Path("reports/r5/match_quality.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
