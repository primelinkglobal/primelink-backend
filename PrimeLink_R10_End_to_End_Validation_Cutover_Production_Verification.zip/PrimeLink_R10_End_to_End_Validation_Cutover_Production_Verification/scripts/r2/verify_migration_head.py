import subprocess, json, os, sys
from pathlib import Path
from sqlalchemy import create_engine, text

report={}
try:
    p=subprocess.run(["alembic","heads"],capture_output=True,text=True,timeout=30)
    heads=[line.split()[0] for line in p.stdout.splitlines() if line.strip()]
    report["repository_heads"]=heads
except Exception as e:
    report["repository_heads"]=[]
    report["repository_error"]=type(e).__name__

db_url=os.getenv("DATABASE_URL","")
try:
    engine=create_engine(db_url,pool_pre_ping=True)
    with engine.connect() as c:
        report["database_revision"]=c.execute(text("select version_num from alembic_version")).scalar()
except Exception as e:
    report["database_revision"]=None
    report["database_error"]=type(e).__name__

heads=report.get("repository_heads") or []
db=report.get("database_revision")
ok=bool(db and heads and db in heads)
report["migration_head_match"]=ok
report["state"]="R2_MIGRATION_HEAD_VERIFIED" if ok else "R2_MIGRATION_REMEDIATION_REQUIRED"
Path("reports/r2").mkdir(parents=True,exist_ok=True)
Path("reports/r2/migration_head_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if ok else 2)
