import os, subprocess, sys, json
from datetime import datetime, timezone
from pathlib import Path

env=os.getenv("APP_ENV","").lower()
url=os.getenv("DATABASE_URL","")
if env!="production":
    print(json.dumps({"state":"BLOCKED","reason":"APP_ENV must be production"},indent=2));sys.exit(2)
if not url.lower().startswith(("postgresql://","postgresql+psycopg://","postgres://")):
    print(json.dumps({"state":"BLOCKED","reason":"PostgreSQL DATABASE_URL required"},indent=2));sys.exit(2)

cmd=["alembic","upgrade","head"]
p=subprocess.run(cmd,text=True,capture_output=True)
report={
    "executed_at":datetime.now(timezone.utc).isoformat(),
    "command":"alembic upgrade head",
    "exit_code":p.returncode,
    "stdout":p.stdout,
    "stderr":p.stderr,
    "state":"R2_MIGRATIONS_APPLIED" if p.returncode==0 else "R2_MIGRATION_FAILED"
}
Path("reports/r2").mkdir(parents=True,exist_ok=True)
Path("reports/r2/migration_execution.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(p.returncode)
