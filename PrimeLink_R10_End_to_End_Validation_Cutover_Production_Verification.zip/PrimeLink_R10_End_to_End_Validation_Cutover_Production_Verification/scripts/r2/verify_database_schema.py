import os, json, sys
from pathlib import Path

def fail(reason, **extra):
    payload={"state":"R2_DATABASE_SCHEMA_REMEDIATION_REQUIRED","reason":reason}
    payload.update(extra)
    print(json.dumps(payload, indent=2))
    sys.exit(2)

url=os.getenv("DATABASE_URL","")
if not url.lower().startswith(("postgresql://","postgresql+psycopg://","postgres://")):
    fail("DATABASE_URL is not a PostgreSQL connection")

try:
    from sqlalchemy import create_engine, inspect, text
except Exception as e:
    fail("SQLAlchemy unavailable", error_type=type(e).__name__)

try:
    engine=create_engine(url,pool_pre_ping=True)
    with engine.connect() as c:
        c.execute(text("select 1"))
    insp=inspect(engine)
    tables=sorted(insp.get_table_names())
    constraints={}
    for t in tables:
        try:
            constraints[t]={
                "pk":insp.get_pk_constraint(t),
                "fks":insp.get_foreign_keys(t),
                "uniques":insp.get_unique_constraints(t),
                "indexes":insp.get_indexes(t)
            }
        except Exception as e:
            constraints[t]={"error_type":type(e).__name__}

    with engine.connect() as c:
        try:
            db_rev=c.execute(text("select version_num from alembic_version")).scalar()
        except Exception:
            db_rev=None

    report={
        "state":"R2_DATABASE_SCHEMA_CONNECTED",
        "table_count":len(tables),
        "tables":tables,
        "database_revision":db_rev,
        "constraints":constraints
    }
    Path("reports/r2").mkdir(parents=True,exist_ok=True)
    Path("reports/r2/live_schema_verification.json").write_text(json.dumps(report,indent=2,default=str))
    print(json.dumps(report,indent=2,default=str))
except Exception as e:
    fail("Database connectivity/schema inspection failed", error_type=type(e).__name__)
