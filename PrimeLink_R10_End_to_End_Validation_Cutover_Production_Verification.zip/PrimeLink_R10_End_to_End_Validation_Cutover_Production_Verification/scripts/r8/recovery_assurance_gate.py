import csv,json,sys
from pathlib import Path
p=Path("evidence/r8/BACKUP_RESTORE.csv")
rows=list(csv.DictReader(p.open())) if p.exists() else []
passed=[r for r in rows if r.get("backup_status")=="PASS" and r.get("restore_status")=="PASS"
        and r.get("integrity_checked","").lower()=="true"
        and r.get("application_ready","").lower()=="true"]
report={
 "tests":len(rows),
 "successful_restore_assurance_tests":len(passed),
 "state":"PASS" if passed else "BLOCK"
}
Path("reports/r8").mkdir(parents=True,exist_ok=True)
Path("reports/r8/recovery_assurance_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if passed else 2)
