import json,sys
from pathlib import Path
from app.core.operations_control import classify_health, privacy_request_action_allowed, recovery_assured

checks={
 "healthy_runtime_ready": classify_health(True,True)=="ready",
 "db_failure_unready": classify_health(False,True)=="unready",
 "dependency_failure_degraded": classify_health(True,False)=="degraded",
 "privacy_without_identity_denied": privacy_request_action_allowed(False,False) is False,
 "legal_hold_blocks_action": privacy_request_action_allowed(True,True) is False,
 "privacy_verified_no_hold_allowed": privacy_request_action_allowed(True,False) is True,
 "backup_alone_not_recovery": recovery_assured(True,False,False,False) is False,
 "full_restore_chain_required": recovery_assured(True,True,True,True) is True,
}
report={"state":"PASS" if all(checks.values()) else "FAIL","checks":checks}
Path("reports/r8").mkdir(parents=True,exist_ok=True)
Path("reports/r8/control_plane_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if all(checks.values()) else 2)
