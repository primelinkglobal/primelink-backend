import csv,json,sys
from pathlib import Path

specs={
 "incidents":("evidence/r8/INCIDENTS.csv",["incident_id","severity","status","owner"]),
 "privacy":("evidence/r8/PRIVACY_REQUESTS.csv",["request_id","request_type","status","owner"]),
 "backups":("evidence/r8/BACKUP_RESTORE.csv",["test_id","backup_status","restore_status","status"]),
 "alerts":("evidence/r8/ALERT_TESTS.csv",["alert_test_id","signal","status","owner"])
}
issues=[];counts={}
for name,(path,required) in specs.items():
 p=Path(path);rows=list(csv.DictReader(p.open())) if p.exists() else []
 counts[name]=len(rows)
 for i,r in enumerate(rows,2):
  for key in required:
   if not (r.get(key) or "").strip():
    issues.append({"register":name,"row":i,"issue":"missing_"+key})

report={"counts":counts,"issues":issues,"state":"PASS" if not issues else "REMEDIATION_REQUIRED"}
Path("reports/r8").mkdir(parents=True,exist_ok=True)
Path("reports/r8/operational_evidence_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not issues else 2)
