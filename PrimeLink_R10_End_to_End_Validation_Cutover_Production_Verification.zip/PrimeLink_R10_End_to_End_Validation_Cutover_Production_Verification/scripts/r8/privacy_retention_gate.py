import csv,json,sys
from pathlib import Path
p=Path("evidence/r8/PRIVACY_REQUESTS.csv")
rows=list(csv.DictReader(p.open())) if p.exists() else []
issues=[]
for i,r in enumerate(rows,2):
    if r.get("status") in {"FULFILLED","CLOSED"} and r.get("identity_verified","").lower()!="true":
        issues.append({"row":i,"issue":"closed_without_identity_verification"})
    if r.get("legal_hold","").lower()=="true" and r.get("disposal_completed","").lower()=="true":
        issues.append({"row":i,"issue":"disposal_during_legal_hold"})
report={"records":len(rows),"issues":issues,"state":"PASS" if not issues else "BLOCK"}
Path("reports/r8").mkdir(parents=True,exist_ok=True)
Path("reports/r8/privacy_retention_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not issues else 2)
