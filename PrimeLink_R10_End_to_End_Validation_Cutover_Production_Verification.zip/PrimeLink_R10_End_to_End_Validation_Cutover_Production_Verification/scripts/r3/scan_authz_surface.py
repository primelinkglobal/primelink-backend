import re,json
from pathlib import Path
rx=re.compile(r'@\w+\.(get|post|put|patch|delete)\(\s*["\']([^"\']+)')
markers=("current_user","require_","permission","role","auth","Depends(");rows=[]
for p in sorted(Path("app").rglob("*.py")):
 t=p.read_text(errors="ignore");ls=t.splitlines()
 for i,l in enumerate(ls):
  m=rx.search(l)
  if m:
   c="\n".join(ls[i:i+12]);rows.append({"source":str(p),"line":i+1,"method":m.group(1).upper(),"path":m.group(2),"authorization_signal":any(x.lower() in c.lower() for x in markers)})
r={"state":"R3_AUTHZ_SURFACE_INVENTORIED","route_count":len(rows),"routes":rows};Path("reports/r3").mkdir(parents=True,exist_ok=True);Path("reports/r3/authz_surface.json").write_text(json.dumps(r,indent=2));print(json.dumps({"state":r["state"],"route_count":len(rows)},indent=2))
