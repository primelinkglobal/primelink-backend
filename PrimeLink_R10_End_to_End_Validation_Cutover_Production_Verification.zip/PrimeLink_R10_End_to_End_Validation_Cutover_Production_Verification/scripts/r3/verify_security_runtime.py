import os,json,sys
from pathlib import Path
env=os.getenv("APP_ENV","").lower(); jwt=os.getenv("JWT_SECRET",""); db=os.getenv("DATABASE_URL","")
truth=lambda x:x.lower() in ("1","true","yes","on")
checks={
 "production_environment":env=="production",
 "jwt_secret_present_and_min_32_bytes":len(jwt.encode())>=32,
 "database_url_present":bool(db),
 "bootstrap_admin_disabled":not truth(os.getenv("ALLOW_BOOTSTRAP_ADMIN","false")),
 "secure_cookies_enabled":truth(os.getenv("SECURE_COOKIES","true")),
 "trusted_proxy_headers_enabled":truth(os.getenv("TRUST_PROXY_HEADERS","true")),
 "cors_explicit":"*" not in [x.strip() for x in os.getenv("CORS_ORIGINS","").split(",") if x.strip()],
 "trusted_hosts_configured":bool(os.getenv("TRUSTED_HOSTS","").strip())
}
r={"state":"R3_SECURITY_RUNTIME_VERIFIED" if all(checks.values()) else "R3_SECURITY_RUNTIME_REMEDIATION_REQUIRED","checks":checks,"note":"Secret values intentionally omitted."}
Path("reports/r3").mkdir(parents=True,exist_ok=True);Path("reports/r3/security_runtime_verification.json").write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));sys.exit(0 if all(checks.values()) else 2)
