import json, sys
from pathlib import Path
from app.core.connector_runtime import ConnectorRegistry
from app.core.connectors import ConnectorError

reg=ConnectorRegistry()
records=reg.run("static_example",{"geography":"dubai","sector_or_asset_type":"real estate"})
r=records[0].to_dict() if records else {}
checks={
    "record_created":bool(r),
    "provenance_present":bool(r.get("source_reference")),
    "attribution_present":bool(r.get("attribution")),
    "starts_unverified":r.get("verification_state")=="discovered_unverified",
    "raw_preserved":isinstance(r.get("raw_payload"),dict),
    "normalized_preserved":isinstance(r.get("normalized_payload"),dict),
}
# deny unknown connector
try:
    reg.run("unknown_connector",{})
    checks["unknown_connector_denied"]=False
except Exception:
    checks["unknown_connector_denied"]=True

report={"state":"PASS" if all(checks.values()) else "FAIL","checks":checks,"sample_record":r}
Path("reports/r6").mkdir(parents=True,exist_ok=True)
Path("reports/r6/connector_contract_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if all(checks.values()) else 2)
