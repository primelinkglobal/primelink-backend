import csv,json,sys
from pathlib import Path
p=Path("evidence/r6/CONNECTOR_HEALTH.csv")
rows=list(csv.DictReader(p.open())) if p.exists() else []
critical=[r for r in rows if r.get("critical","").lower()=="true"]
bad=[r for r in critical if r.get("status")!="PASS"]
report={"critical_connectors":len(critical),"blocking":[{"connector_id":r.get("connector_id"),"status":r.get("status")} for r in bad]}
report["state"]="PASS" if not bad else "BLOCK"
Path("reports/r6").mkdir(parents=True,exist_ok=True)
Path("reports/r6/connector_health_gate.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not bad else 2)
