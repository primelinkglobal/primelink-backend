import csv,json,sys
from pathlib import Path

p=Path("evidence/r6/DISCOVERY_RECORDS.csv")
rows=list(csv.DictReader(p.open())) if p.exists() else []
issues=[]
for i,r in enumerate(rows,2):
    for key in ("record_id","connector_id","source_name","source_reference","retrieved_at","verification_state"):
        if not (r.get(key) or "").strip():
            issues.append({"row":i,"issue":"missing_"+key})
    if r.get("verification_state")=="verified" and not (r.get("verified_by") or "").strip():
        issues.append({"row":i,"issue":"verified_without_verified_by"})
report={"records":len(rows),"issues":issues,"state":"PASS" if not issues else "REMEDIATION_REQUIRED"}
Path("reports/r6").mkdir(parents=True,exist_ok=True)
Path("reports/r6/provenance_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(0 if not issues else 2)
