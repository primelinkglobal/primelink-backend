# PrimeLink Capital — R1 Unified Production Application Baseline

R1 consolidates the existing PrimeLink FastAPI production backend and a new public application shell into one deployable application.

## Included
- FastAPI application and existing PrimeLink API routes
- PostgreSQL / SQLAlchemy / Alembic baseline
- Authentication and security boundaries inherited from the FPA-5 application
- Opportunity, workflow, intelligence, discovery, commercial, privacy and monitoring routes
- Redesigned PrimeLink Capital application shell
- `/health/live`, `/health/ready`, `/runtime`, `/docs`, and metrics support
- Render Blueprint and Docker deployment definitions
- production-safe environment template with no real secrets

## Production controls
Real `DATABASE_URL` and `JWT_SECRET` values must be injected by the deployment platform.
Automatic introductions and external discovery are disabled at the R1 baseline.
Database schema changes use Alembic migrations.

## R1 state
`UNIFIED_APPLICATION_BASELINE_READY`

This state means the application baseline is assembled and deployable. It does not claim the live production environment has passed the FPA gates.


## R2 database baseline
R2 adds PostgreSQL schema inspection, migration-head verification, a controlled Alembic migration runner, and schema/constraint/lifecycle evidence registers. Live verification still requires the deployed PostgreSQL runtime.


## R3 security runtime
R3 formalizes authentication, deny-by-default RBAC, production security verification, HTTP security headers and authorization evidence controls.

## R4 business core
R4 formalizes PrimeLink's investor mandate, partner, opportunity, relationship and CRM operating records, with explicit lifecycle, source, verification and introduction-readiness controls.

## R5 intelligence
R5 adds explainable candidate matching, human-review thresholds, provenance, versioned matching rules and outcome-quality measurement. Match scores never authorize introductions automatically.

## R6 external discovery
R6 adds a deny-by-default connector runtime, provenance-preserving discovery records, source verification states, safe-failure behavior and connector health evidence. External discovery remains disabled until approved sources are configured.

## R7 commercial workflows
R7 adds protected-introduction commercial controls, decimal-safe fee computation, invoice eligibility, collections, reconciliation and revenue-pipeline evidence. Projected, earned, invoiced, collected and reconciled values remain distinct.

## R8 control plane
R8 adds service health, incidents, alert evidence, privacy request operations, retention/legal hold controls, audit events, backup/restore assurance, release evidence and operational risk tracking.

## R9 automated deployment
R9 adds repeatable build, environment verification, controlled migrations, post-deploy smoke tests, release gates, rollback readiness and deployment evidence. Secrets remain external to source control.

## R10 final validation and cutover
R10 is the final rebuild stage. It adds end-to-end validation, public smoke testing, cutover and rollback gates, post-cutover observation, named production ownership and a final evidence-based production verification gate.
