# R7 — Commercial & Revenue Workflows

R7 implements the controlled commercial lifecycle for PrimeLink.

Commercial agreements provide the basis for protected introductions and fee events. A fee event remains potential or qualified until the defined trigger is satisfied. An earned fee may become invoice-eligible only after approval.

The workflow separates projected, potential, earned, invoiced, collected and reconciled values. This prevents pipeline value from being presented as realized cash.

Money calculations use decimal arithmetic and explicit currency codes. Invoice identifiers, adjustments, waivers, disputes, receipts and reconciliation events are intended to remain attributable and auditable.
