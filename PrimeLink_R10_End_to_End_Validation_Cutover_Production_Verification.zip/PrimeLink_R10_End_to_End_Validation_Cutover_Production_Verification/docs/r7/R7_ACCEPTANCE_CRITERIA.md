# R7 Acceptance Criteria

Baseline `R7_COMMERCIAL_REVENUE_WORKFLOWS_READY` requires:
- commercial contract and lifecycle;
- decimal/currency-safe fee engine;
- agreement, introduction, fee, invoice, collection and reconciliation registers;
- duplicate-control verification tooling;
- revenue-state policy;
- UI integration;
- successful Python compilation.

Live `R7_COMMERCIAL_REVENUE_WORKFLOWS_VERIFIED` additionally requires:
- real commercial agreements are attributable and retrievable;
- protected introductions reference approved commercial context;
- fee triggers are evidenced;
- duplicate fee/invoice tests pass;
- invoices and collections maintain distinct states;
- reconciliation identifies exact matches and exceptions;
- RBAC protects material commercial actions;
- no unresolved critical/high R7 exception remains.
