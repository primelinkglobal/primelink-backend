# R4 Acceptance Criteria

Baseline `R4_BUSINESS_CORE_READY` requires:
- explicit domain/lifecycle/data-quality policies;
- business-core route and model inventory tooling;
- investor mandate, opportunity, partner, relationship, CRM, workflow and introduction-readiness evidence registers;
- business-facing application shell additions;
- successful Python compilation.

Live `R4_BUSINESS_CORE_VERIFIED` additionally requires:
- real production records can be created/read/updated under RBAC;
- lifecycle transitions are enforced;
- ownership and source fields are present;
- verified/unverified data is distinguishable;
- CRM events are attributable;
- duplicate and invalid-state tests pass;
- protected introduction readiness does not bypass human review;
- no unresolved critical/high R4 exception remains.
