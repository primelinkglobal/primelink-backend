# R4 — Opportunity, Investor, Partner & CRM Core

R4 turns PrimeLink's business model into structured operating records.

## Investor mandates
Investor requirements are managed as owned lifecycle records with geography, sector/asset type, ticket or capacity, liquidity/risk context, source and verification state.

## Opportunities
Opportunities have a lifecycle distinct from matching: draft → submitted → screening → verified → active → matched → introduced → closed/rejected.

## Partners
Strategic partners are maintained separately from investors and opportunities. Their capability, market coverage, status and verification state are explicit.

## CRM & relationship intelligence
Activities, relationship state and next actions are attributable and timestamped. Message history alone is not treated as authoritative relationship status.

## Introduction readiness
Readiness combines due diligence, human review, relationship ownership and commercial terms. R4 does not permit automatic introductions.
