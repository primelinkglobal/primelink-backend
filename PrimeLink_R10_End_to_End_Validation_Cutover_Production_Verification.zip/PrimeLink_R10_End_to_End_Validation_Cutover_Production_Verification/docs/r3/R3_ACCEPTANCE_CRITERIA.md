# R3 Acceptance Criteria
Baseline `R3_AUTH_RBAC_SECURITY_RUNTIME_READY` requires externalized secrets, authentication policy, deny-by-default RBAC, runtime verification tooling, authorization-surface inventory, HTTP security headers, evidence registers and successful Python compilation.

Live `R3_AUTH_RBAC_SECURITY_RUNTIME_VERIFIED` additionally requires real authentication/authorization tests, denial of expired/invalid tokens, runtime configuration verification, observed HTTPS security headers, auditable privileged events and no unresolved critical/high R3 exception.
