# R3 — Authentication, RBAC & Security Runtime
R3 formalizes the security boundary carried forward from R2.

Authentication secrets remain external to source control. The policy requires Argon2/pwdlib password hashing and a high-entropy external JWT secret. RBAC is deny-by-default with separate administrative, operating, review, commercial, audit and participant boundaries. AI match generation never authorizes an automatic introduction.

R3 also adds same-origin HTTP security headers and explicit evidence registers. Baseline readiness is not live certification; production tests remain required.
