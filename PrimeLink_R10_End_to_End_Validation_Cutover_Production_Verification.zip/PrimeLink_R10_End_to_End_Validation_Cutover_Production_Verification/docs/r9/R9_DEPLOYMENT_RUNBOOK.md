# R9 — Automated Production Deployment Runbook

## Deployment flow
1. Commit or identify the release candidate.
2. Build dependencies using the repository `requirements.txt`.
3. Verify production environment configuration without printing secret values.
4. Apply `alembic upgrade head` through the R2 migration runner.
5. Start the FastAPI service.
6. Verify `/health/live`.
7. Verify `/health/ready`.
8. Run R9 post-deploy smoke checks across the application control endpoints.
9. Confirm rollback readiness.
10. Populate the release-gate evidence.
11. Approve or hold the release.

## Secret handling
`DATABASE_URL` and `JWT_SECRET` are deployment-platform secrets. They must not be committed to source control, deployment logs, or evidence files.

## Failed deployment
A failed environment check, migration, readiness check, critical smoke test, or critical release exception blocks production approval.
