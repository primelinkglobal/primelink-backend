# R9 Acceptance Criteria

Baseline `R9_AUTOMATED_DEPLOYMENT_READY` requires:
- automated build/predeploy/start configuration;
- explicit production environment contract;
- migration gate;
- post-deploy health/smoke verification;
- release gate;
- rollback readiness gate;
- deployment/release evidence registers;
- successful Python compilation.

Live `R9_AUTOMATED_DEPLOYMENT_VERIFIED` additionally requires:
- a real production deployment succeeds;
- secrets are configured in the deployment platform;
- migrations reach the approved head;
- liveness and readiness pass;
- post-deploy smoke verification passes;
- rollback readiness is evidenced;
- no critical release exception remains;
- release approval is recorded.
