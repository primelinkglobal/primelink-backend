# R8 Acceptance Criteria

Baseline `R8_CONTROL_PLANE_READY` requires:
- control-plane contract;
- observability, privacy/retention and resilience policies;
- operational control module;
- incident/alert/privacy/retention/backup/release/audit registers;
- privacy and recovery gates;
- control-plane UI integration;
- successful Python compilation.

Live `R8_CONTROL_PLANE_VERIFIED` additionally requires:
- production health and readiness evidence;
- critical alert routing to a real operator;
- incident ownership and response evidence;
- privacy request identity-verification controls work;
- legal hold blocks disposal;
- backup and isolated restore test succeeds;
- audit/release evidence is populated;
- no unresolved critical/high R8 exception remains.
