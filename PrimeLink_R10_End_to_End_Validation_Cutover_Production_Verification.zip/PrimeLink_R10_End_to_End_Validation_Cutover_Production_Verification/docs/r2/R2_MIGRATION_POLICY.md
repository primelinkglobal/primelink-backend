# R2 Migration Policy

1. Every production schema change must be represented by an Alembic migration.
2. Direct ad-hoc production DDL is not an approved deployment path.
3. Migration review must identify destructive operations, lock risk and data transformation impact.
4. Material migrations require a tested rollback/recovery approach.
5. Production deployment must record the approved repository head and resulting database revision.
6. A migration is not considered complete until application readiness passes against the migrated schema.
7. Database credentials are never embedded in migration files, repository history or evidence.
