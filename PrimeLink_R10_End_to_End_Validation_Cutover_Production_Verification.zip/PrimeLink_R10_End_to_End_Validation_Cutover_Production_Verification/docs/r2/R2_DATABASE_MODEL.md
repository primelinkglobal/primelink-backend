# R2 — Production Database Schema & Migration Baseline

R2 carries forward the R1 application and formalizes its PostgreSQL data layer.

## Discovered ORM/declared tables
- `agreement_records` — `app/models/entities.py`
- `ai_audit_events` — `app/models/entities.py`
- `ai_evaluations` — `app/models/entities.py`
- `ai_match_candidates` — `app/models/entities.py`
- `ai_match_runs` — `app/models/entities.py`
- `ai_model_versions` — `app/models/entities.py`
- `audit_events` — `app/models/entities.py`
- `audit_integrity_checkpoints` — `app/models/entities.py`
- `auth_tokens` — `app/models/entities.py`
- `backup_status` — `app/models/entities.py`
- `collection_records` — `app/models/entities.py`
- `commercial_audit_events` — `app/models/entities.py`
- `commercial_cases` — `app/models/entities.py`
- `connector_health_checks` — `app/models/entities.py`
- `crm_activities` — `app/models/entities.py`
- `discovered_candidates` — `app/models/entities.py`
- `discovery_audit_events` — `app/models/entities.py`
- `discovery_runs` — `app/models/entities.py`
- `discovery_sources` — `app/models/entities.py`
- `fee_events` — `app/models/entities.py`
- `introduction_preparations` — `app/models/entities.py`
- `invoice_records` — `app/models/entities.py`
- `legal_holds` — `app/models/entities.py`
- `login_events` — `app/models/entities.py`
- `mandates` — `app/models/entities.py`
- `match_records` — `app/models/entities.py`
- `notification_outbox` — `app/models/entities.py`
- `onboarding_applications` — `app/models/entities.py`
- `opportunities` — `app/models/entities.py`
- `opportunity_activities` — `app/models/entities.py`
- `participants` — `app/models/entities.py`
- `prior_relationship_checks` — `app/models/entities.py`
- `privacy_requests` — `app/models/entities.py`
- `protected_introductions` — `app/models/entities.py`
- `referral_allocations` — `app/models/entities.py`
- `relationship_claim_checks` — `app/models/entities.py`
- `relationships` — `app/models/entities.py`
- `retention_rules` — `app/models/entities.py`
- `review_decisions` — `app/models/entities.py`
- `security_events` — `app/models/entities.py`
- `tasks` — `app/models/entities.py`
- `users` — `app/models/entities.py`
- `worker_heartbeats` — `app/models/entities.py`
- `workflow_events` — `app/models/entities.py`

## Controls added
- PostgreSQL-only live schema verifier;
- migration-head verifier;
- controlled `alembic upgrade head` wrapper;
- schema inventory/evidence register;
- migration register;
- constraint verification register;
- data lifecycle register;
- exception register;
- explicit no-destructive-change rule.

The discovered table list is static source evidence only. The live database remains authoritative once deployed.
