# R2 Acceptance Criteria

R2 reaches `R2_DATABASE_SCHEMA_MIGRATION_BASELINE_READY` when the package:
- retains a PostgreSQL-compatible SQLAlchemy/Alembic application baseline;
- includes migration and schema verification gates;
- contains no embedded production database secret;
- compiles successfully;
- exposes evidence registers for schema, migrations, constraints and lifecycle.

R2 reaches the later live state `R2_DATABASE_SCHEMA_MIGRATION_VERIFIED` only after:
- the real production PostgreSQL database is reachable;
- `alembic upgrade head` succeeds;
- database revision matches the approved repository head;
- required tables/constraints exist;
- application readiness succeeds after migration;
- no critical R2 exception remains open.
