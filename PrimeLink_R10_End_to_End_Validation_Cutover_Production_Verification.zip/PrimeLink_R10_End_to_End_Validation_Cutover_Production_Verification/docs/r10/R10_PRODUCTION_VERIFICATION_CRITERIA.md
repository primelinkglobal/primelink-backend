# R10 Production Verification Criteria

PrimeLink may be declared `PRIMELINK_REBUILD_PRODUCTION_VERIFIED` only when:

- the approved production release is identifiable;
- liveness and readiness pass;
- PostgreSQL connectivity and migration head are verified;
- authentication and RBAC tests pass;
- business-core workflows pass;
- AI matching remains explainable and human-reviewed;
- external discovery preserves provenance and unverified state;
- commercial workflow integrity passes;
- privacy, audit, backup/restore and resilience controls pass;
- automated deployment and rollback are proven;
- post-cutover validation passes;
- no critical exception remains open;
- required production owners accept responsibility.

Generated code or documentation alone cannot satisfy these criteria.
