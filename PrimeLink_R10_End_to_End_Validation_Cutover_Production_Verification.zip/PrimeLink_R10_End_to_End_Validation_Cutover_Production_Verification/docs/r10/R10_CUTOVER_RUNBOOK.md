# R10 — Cutover Runbook

## Before cutover
1. Freeze the approved release candidate.
2. Verify R9 live deployment and R10 cutover-readiness gates.
3. Confirm production database backup and tested rollback path.
4. Record the current production target and rollback target.
5. Confirm production, security/privacy, incident/rollback, commercial and business approvers.
6. Confirm domain/DNS changes and TTL strategy if a domain switch is required.

## Cutover
1. Deploy the approved application release.
2. Confirm liveness and readiness before routing production traffic.
3. Route `primelinkcapital.com` to the approved application target.
4. Run the public smoke suite immediately.
5. Run business/authentication/matching/commercial critical-flow checks.
6. Observe errors, latency, database failures, authentication failures and critical security signals.
7. Approve or trigger rollback.

## Rollback
Rollback is mandatory if a critical gate fails and the issue cannot be contained within the approved window.
The rollback event must preserve evidence and verify data integrity after restoration of service.

## After cutover
Populate post-cutover observation evidence and run the final production-verification gate.
Only a complete PASS may issue `PRIMELINK_REBUILD_PRODUCTION_VERIFIED`.
