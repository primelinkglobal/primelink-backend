# R6 Acceptance Criteria

Baseline `R6_EXTERNAL_DISCOVERY_CONNECTOR_RUNTIME_READY` requires:
- external discovery contract;
- deny-by-default connector registry;
- provenance/verification policy;
- connector interface and guarded runtime;
- connector/provenance/failure evidence registers;
- connector contract verification;
- UI integration;
- successful Python compilation.

Live `R6_EXTERNAL_DISCOVERY_CONNECTOR_RUNTIME_VERIFIED` additionally requires:
- each enabled production connector is approved and owned;
- credentials are externally managed;
- health checks pass;
- provenance is preserved on real records;
- discovered records remain unverified until reviewed;
- connector failure degrades safely;
- no fabricated source/result is produced;
- no unresolved critical/high R6 exception remains.
