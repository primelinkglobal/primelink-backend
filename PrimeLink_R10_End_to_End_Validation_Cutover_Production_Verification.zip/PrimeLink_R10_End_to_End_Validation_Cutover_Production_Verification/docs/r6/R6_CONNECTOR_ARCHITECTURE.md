# R6 — External Discovery & Connector Runtime

R6 introduces the controlled external-information boundary for PrimeLink.

The connector runtime is deny-by-default. External sources must be approved and registered before operational use. Credentials remain in the deployment secret store, not source control.

Every accepted discovery record preserves source reference, retrieval context, raw payload, normalized payload, attribution and verification state. External information begins as `discovered_unverified`; it does not become verified merely because a connector returned it.

Provider failures degrade safely. R6 does not fabricate replacement results and does not bypass human review, matching governance or protected-introduction controls.
