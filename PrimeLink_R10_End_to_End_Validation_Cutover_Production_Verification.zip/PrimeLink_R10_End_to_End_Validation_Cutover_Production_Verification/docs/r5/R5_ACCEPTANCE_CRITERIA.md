# R5 Acceptance Criteria

Baseline `R5_AI_MATCHING_INTELLIGENCE_READY` requires:
- matching/intelligence contract;
- explicit weighted matching policy;
- explanation/provenance policy;
- deterministic replayable candidate scoring;
- human-review thresholding;
- quality measurement framework;
- match/review/provenance/version evidence registers;
- UI integration;
- successful Python compilation.

Live `R5_AI_MATCHING_INTELLIGENCE_VERIFIED` additionally requires:
- production mandates/opportunities generate candidates successfully;
- score explanations are complete;
- verified/unverified source states remain correct;
- human-review workflow records decisions;
- no automatic introduction occurs;
- match quality metrics are produced from real outcomes;
- no unresolved critical/high R5 exception remains.
