# R5 — AI Matching & Opportunity Intelligence

R5 creates the PrimeLink candidate-generation and decision-support layer.

The baseline matching engine is intentionally deterministic and explainable. It scores mandate/opportunity fit across geography, sector/asset type, ticket/capacity, liquidity horizon, risk, transaction structure, relationship context and verification quality.

R5 does not equate a score with a decision. Candidates above review thresholds are routed to human review. Protected introductions remain a separate governed action.

Future machine-learned or LLM-assisted components can sit behind the same contract provided they preserve explanation, provenance, versioning, verification state and human-review requirements.
