from datetime import datetime
from sqlalchemy import String, Integer, DateTime, Text, Boolean, Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(500))
    role: Mapped[str] = mapped_column(String(50), default="operator")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Participant(Base):
    __tablename__ = "participants"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_type: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(250), index=True)
    organization: Mapped[str | None] = mapped_column(String(250), nullable=True)
    geography: Mapped[str | None] = mapped_column(String(120), nullable=True)
    verification_state: Mapped[str] = mapped_column(String(60), default="UNVERIFIED")
    status: Mapped[str] = mapped_column(String(40), default="PENDING")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Mandate(Base):
    __tablename__ = "mandates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"))
    objective: Mapped[str] = mapped_column(String(250))
    geography: Mapped[str] = mapped_column(String(120))
    sector: Mapped[str] = mapped_column(String(120))
    ticket_min: Mapped[float | None] = mapped_column(Float, nullable=True)
    ticket_max: Mapped[float | None] = mapped_column(Float, nullable=True)
    constraints: Mapped[str | None] = mapped_column(Text, nullable=True)
    freshness: Mapped[str] = mapped_column(String(30), default="CURRENT")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Opportunity(Base):
    __tablename__ = "opportunities"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(250))
    opportunity_type: Mapped[str] = mapped_column(String(120))
    geography: Mapped[str] = mapped_column(String(120))
    sector: Mapped[str] = mapped_column(String(120))
    value: Mapped[float | None] = mapped_column(Float, nullable=True)
    stage: Mapped[str] = mapped_column(String(80), default="SUBMITTED")
    source: Mapped[str] = mapped_column(String(250))
    provenance: Mapped[str | None] = mapped_column(Text, nullable=True)
    verification_state: Mapped[str] = mapped_column(String(60), default="DISCOVERED_UNVERIFIED")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Relationship(Base):
    __tablename__ = "relationships"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"))
    owner_email: Mapped[str] = mapped_column(String(320))
    status: Mapped[str] = mapped_column(String(50), default="ACTIVE")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_interaction: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class MatchRecord(Base):
    __tablename__ = "match_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mandate_id: Mapped[int] = mapped_column(ForeignKey("mandates.id"))
    opportunity_id: Mapped[int] = mapped_column(ForeignKey("opportunities.id"))
    score: Mapped[float] = mapped_column(Float)
    explanation: Mapped[str] = mapped_column(Text)
    human_review_state: Mapped[str] = mapped_column(String(50), default="PENDING")
    introduction_eligible: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class CommercialCase(Base):
    __tablename__ = "commercial_cases"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    opportunity_id: Mapped[int | None] = mapped_column(ForeignKey("opportunities.id"), nullable=True)
    agreement_reference: Mapped[str | None] = mapped_column(String(250), nullable=True)
    commercial_state: Mapped[str] = mapped_column(String(60), default="QUALIFIED")
    fee_trigger: Mapped[str | None] = mapped_column(String(250), nullable=True)
    currency: Mapped[str | None] = mapped_column(String(10), nullable=True)
    amount_estimate: Mapped[float | None] = mapped_column(Float, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor: Mapped[str] = mapped_column(String(320))
    action: Mapped[str] = mapped_column(String(120))
    entity_type: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80))
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class AuthToken(Base):
    __tablename__ = "auth_tokens"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    token_type: Mapped[str] = mapped_column(String(40), index=True)  # REFRESH, RESET, VERIFY
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    used_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class LoginEvent(Base):
    __tablename__ = "login_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), index=True)
    success: Mapped[bool] = mapped_column(Boolean)
    ip_address: Mapped[str | None] = mapped_column(String(80), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class OpportunityActivity(Base):
    __tablename__ = "opportunity_activities"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    opportunity_id: Mapped[int] = mapped_column(ForeignKey("opportunities.id"), index=True)
    actor_email: Mapped[str] = mapped_column(String(320))
    activity_type: Mapped[str] = mapped_column(String(80))
    from_state: Mapped[str | None] = mapped_column(String(80), nullable=True)
    to_state: Mapped[str | None] = mapped_column(String(80), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class CRMActivity(Base):
    __tablename__ = "crm_activities"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"), index=True)
    owner_email: Mapped[str] = mapped_column(String(320), index=True)
    activity_type: Mapped[str] = mapped_column(String(80))
    channel: Mapped[str | None] = mapped_column(String(60), nullable=True)
    subject: Mapped[str | None] = mapped_column(String(250), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    next_action_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    task_type: Mapped[str] = mapped_column(String(80), index=True)
    title: Mapped[str] = mapped_column(String(250))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_email: Mapped[str] = mapped_column(String(320), index=True)
    entity_type: Mapped[str | None] = mapped_column(String(80), nullable=True)
    entity_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="OPEN", index=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class ReviewDecision(Base):
    __tablename__ = "review_decisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(80), index=True)
    entity_id: Mapped[str] = mapped_column(String(80), index=True)
    review_type: Mapped[str] = mapped_column(String(80), index=True)
    reviewer_email: Mapped[str] = mapped_column(String(320))
    decision: Mapped[str] = mapped_column(String(60))
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class WorkflowEvent(Base):
    __tablename__ = "workflow_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    entity_type: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80))
    payload_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="PENDING", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class NotificationOutbox(Base):
    __tablename__ = "notification_outbox"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    recipient: Mapped[str] = mapped_column(String(320), index=True)
    channel: Mapped[str] = mapped_column(String(40), default="EMAIL")
    template_key: Mapped[str] = mapped_column(String(100))
    subject: Mapped[str | None] = mapped_column(String(250), nullable=True)
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(40), default="PENDING", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class IntroductionPreparation(Base):
    __tablename__ = "introduction_preparations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("match_records.id"), index=True)
    relationship_owner_email: Mapped[str] = mapped_column(String(320))
    human_review_complete: Mapped[bool] = mapped_column(Boolean, default=False)
    verification_complete: Mapped[bool] = mapped_column(Boolean, default=False)
    compliance_gate_passed: Mapped[bool] = mapped_column(Boolean, default=False)
    counterparty_consent_complete: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(50), default="PREPARATION")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AIModelVersion(Base):
    __tablename__="ai_model_versions"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    provider: Mapped[str]=mapped_column(String(80))
    model_name: Mapped[str]=mapped_column(String(160))
    version_label: Mapped[str]=mapped_column(String(120),index=True)
    prompt_version: Mapped[str]=mapped_column(String(120))
    active: Mapped[bool]=mapped_column(Boolean,default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class AIMatchRun(Base):
    __tablename__="ai_match_runs"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    mandate_id: Mapped[int]=mapped_column(ForeignKey("mandates.id"),index=True)
    model_version: Mapped[str]=mapped_column(String(120))
    candidate_count: Mapped[int]=mapped_column(Integer,default=0)
    status: Mapped[str]=mapped_column(String(40),default="COMPLETED")
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class AIMatchCandidate(Base):
    __tablename__="ai_match_candidates"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    run_id: Mapped[int]=mapped_column(ForeignKey("ai_match_runs.id"),index=True)
    opportunity_id: Mapped[int]=mapped_column(ForeignKey("opportunities.id"),index=True)
    structured_score: Mapped[float]=mapped_column(Float)
    semantic_score: Mapped[float]=mapped_column(Float)
    final_score: Mapped[float]=mapped_column(Float,index=True)
    explanation: Mapped[str]=mapped_column(Text)
    evidence_json: Mapped[str | None]=mapped_column(Text,nullable=True)
    human_review_state: Mapped[str]=mapped_column(String(40),default="PENDING")
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class AIEvaluation(Base):
    __tablename__="ai_evaluations"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    run_id: Mapped[int | None]=mapped_column(ForeignKey("ai_match_runs.id"),nullable=True)
    metric_name: Mapped[str]=mapped_column(String(100),index=True)
    metric_value: Mapped[float]=mapped_column(Float)
    dataset_version: Mapped[str]=mapped_column(String(120))
    notes: Mapped[str | None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)

class AIAuditEvent(Base):
    __tablename__="ai_audit_events"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    actor: Mapped[str]=mapped_column(String(320))
    action: Mapped[str]=mapped_column(String(100),index=True)
    model_version: Mapped[str | None]=mapped_column(String(120),nullable=True)
    entity_type: Mapped[str]=mapped_column(String(80))
    entity_id: Mapped[str]=mapped_column(String(80))
    details_json: Mapped[str | None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime,default=datetime.utcnow)


class DiscoverySource(Base):
    __tablename__ = "discovery_sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(250))
    source_type: Mapped[str] = mapped_column(String(80))
    purpose: Mapped[str] = mapped_column(Text)
    approved_scope: Mapped[str] = mapped_column(Text)
    terms_permission_status: Mapped[str] = mapped_column(String(80), default="PENDING_REVIEW")
    provenance_method: Mapped[str] = mapped_column(String(120))
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(40), default="WATCH")
    owner_email: Mapped[str] = mapped_column(String(320))
    last_reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class DiscoveryRun(Base):
    __tablename__ = "discovery_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    mandate_id: Mapped[int] = mapped_column(ForeignKey("mandates.id"), index=True)
    requested_by: Mapped[str] = mapped_column(String(320))
    source_count: Mapped[int] = mapped_column(Integer, default=0)
    result_count: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(40), default="COMPLETED")
    query_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class DiscoveredCandidate(Base):
    __tablename__ = "discovered_candidates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    discovery_run_id: Mapped[int] = mapped_column(ForeignKey("discovery_runs.id"), index=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("discovery_sources.id"), index=True)
    source_object_id: Mapped[str | None] = mapped_column(String(250), nullable=True)
    canonical_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    title: Mapped[str] = mapped_column(String(500))
    opportunity_type: Mapped[str | None] = mapped_column(String(120), nullable=True)
    geography: Mapped[str | None] = mapped_column(String(120), nullable=True)
    sector: Mapped[str | None] = mapped_column(String(120), nullable=True)
    value: Mapped[float | None] = mapped_column(Float, nullable=True)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    provenance_json: Mapped[str] = mapped_column(Text)
    retrieved_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    verification_state: Mapped[str] = mapped_column(String(60), default="DISCOVERED_UNVERIFIED")
    review_state: Mapped[str] = mapped_column(String(40), default="PENDING")
    normalized_fingerprint: Mapped[str] = mapped_column(String(128), index=True)
    duplicate_of_id: Mapped[int | None] = mapped_column(ForeignKey("discovered_candidates.id"), nullable=True)
    imported_opportunity_id: Mapped[int | None] = mapped_column(ForeignKey("opportunities.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ConnectorHealthCheck(Base):
    __tablename__ = "connector_health_checks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("discovery_sources.id"), index=True)
    reachable: Mapped[bool] = mapped_column(Boolean)
    provenance_working: Mapped[bool] = mapped_column(Boolean)
    scope_enforced: Mapped[bool] = mapped_column(Boolean)
    latency_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    error_rate: Mapped[float | None] = mapped_column(Float, nullable=True)
    decision: Mapped[str] = mapped_column(String(50))
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class DiscoveryAuditEvent(Base):
    __tablename__ = "discovery_audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor: Mapped[str] = mapped_column(String(320))
    action: Mapped[str] = mapped_column(String(100), index=True)
    source_id: Mapped[int | None] = mapped_column(ForeignKey("discovery_sources.id"), nullable=True)
    entity_type: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80))
    details_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class OnboardingApplication(Base):
    __tablename__ = "onboarding_applications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    participant_type: Mapped[str] = mapped_column(String(80), index=True)
    applicant_name: Mapped[str] = mapped_column(String(250))
    organization: Mapped[str | None] = mapped_column(String(250), nullable=True)
    email: Mapped[str] = mapped_column(String(320), index=True)
    geography: Mapped[str | None] = mapped_column(String(120), nullable=True)
    sectors: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str | None] = mapped_column(String(120), nullable=True)
    profile_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    terms_accepted: Mapped[bool] = mapped_column(Boolean, default=False)
    verification_required: Mapped[bool] = mapped_column(Boolean, default=True)
    verification_state: Mapped[str] = mapped_column(String(60), default="PENDING")
    review_state: Mapped[str] = mapped_column(String(60), default="PENDING")
    reviewer_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    review_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    participant_id: Mapped[int | None] = mapped_column(ForeignKey("participants.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class AgreementRecord(Base):
    __tablename__ = "agreement_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agreement_type: Mapped[str] = mapped_column(String(100), index=True)
    agreement_reference: Mapped[str] = mapped_column(String(250), unique=True, index=True)
    party_a: Mapped[str] = mapped_column(String(250))
    party_b: Mapped[str] = mapped_column(String(250))
    participant_id: Mapped[int | None] = mapped_column(ForeignKey("participants.id"), nullable=True)
    effective_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expiry_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    fee_mechanism: Mapped[str | None] = mapped_column(String(120), nullable=True)
    fee_trigger: Mapped[str | None] = mapped_column(Text, nullable=True)
    payment_terms: Mapped[str | None] = mapped_column(Text, nullable=True)
    referral_allocation_terms: Mapped[str | None] = mapped_column(Text, nullable=True)
    version_label: Mapped[str] = mapped_column(String(80), default="1.0")
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    record_location: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_email: Mapped[str] = mapped_column(String(320))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ProtectedIntroduction(Base):
    __tablename__ = "protected_introductions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preparation_id: Mapped[int] = mapped_column(ForeignKey("introduction_preparations.id"), index=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("match_records.id"), index=True)
    agreement_id: Mapped[int | None] = mapped_column(ForeignKey("agreement_records.id"), nullable=True)
    party_a_reference: Mapped[str] = mapped_column(String(250))
    party_b_reference: Mapped[str] = mapped_column(String(250))
    relationship_owner_email: Mapped[str] = mapped_column(String(320))
    authorized_by: Mapped[str] = mapped_column(String(320))
    channel: Mapped[str] = mapped_column(String(60))
    introduction_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    prior_relationship_checked: Mapped[bool] = mapped_column(Boolean, default=False)
    compliance_gate_passed: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(50), default="AUTHORIZED")
    introduced_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class PriorRelationshipCheck(Base):
    __tablename__ = "prior_relationship_checks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    introduction_id: Mapped[int] = mapped_column(ForeignKey("protected_introductions.id"), index=True)
    checked_by: Mapped[str] = mapped_column(String(320))
    prior_relationship_found: Mapped[bool] = mapped_column(Boolean, default=False)
    prior_claimant: Mapped[str | None] = mapped_column(String(250), nullable=True)
    evidence_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    decision: Mapped[str] = mapped_column(String(60), default="CLEAR")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class FeeEvent(Base):
    __tablename__ = "fee_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    commercial_case_id: Mapped[int] = mapped_column(ForeignKey("commercial_cases.id"), index=True)
    agreement_id: Mapped[int] = mapped_column(ForeignKey("agreement_records.id"), index=True)
    introduction_id: Mapped[int | None] = mapped_column(ForeignKey("protected_introductions.id"), nullable=True)
    trigger_type: Mapped[str] = mapped_column(String(120))
    trigger_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    event_evidence: Mapped[str | None] = mapped_column(Text, nullable=True)
    calculation_basis: Mapped[str | None] = mapped_column(Text, nullable=True)
    currency: Mapped[str | None] = mapped_column(String(10), nullable=True)
    amount: Mapped[float | None] = mapped_column(Float, nullable=True)
    duplicate_claim: Mapped[bool] = mapped_column(Boolean, default=False)
    approval_state: Mapped[str] = mapped_column(String(60), default="PENDING")
    status: Mapped[str] = mapped_column(String(60), default="PENDING")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class InvoiceRecord(Base):
    __tablename__ = "invoice_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fee_event_id: Mapped[int] = mapped_column(ForeignKey("fee_events.id"), index=True)
    invoice_reference: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    bill_to: Mapped[str] = mapped_column(String(250))
    currency: Mapped[str] = mapped_column(String(10))
    amount: Mapped[float] = mapped_column(Float)
    due_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="DRAFT")
    paid_amount: Mapped[float] = mapped_column(Float, default=0.0)
    record_location: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class CollectionRecord(Base):
    __tablename__ = "collection_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("invoice_records.id"), index=True)
    payer: Mapped[str] = mapped_column(String(250))
    currency: Mapped[str] = mapped_column(String(10))
    amount: Mapped[float] = mapped_column(Float)
    payment_reference: Mapped[str] = mapped_column(String(250), unique=True)
    reconciled: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(50), default="RECEIVED")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ReferralAllocation(Base):
    __tablename__ = "referral_allocations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fee_event_id: Mapped[int] = mapped_column(ForeignKey("fee_events.id"), index=True)
    partner_participant_id: Mapped[int] = mapped_column(ForeignKey("participants.id"), index=True)
    governing_agreement_id: Mapped[int] = mapped_column(ForeignKey("agreement_records.id"))
    calculation_basis: Mapped[str] = mapped_column(Text)
    currency: Mapped[str] = mapped_column(String(10))
    amount: Mapped[float] = mapped_column(Float)
    approval_state: Mapped[str] = mapped_column(String(60), default="PENDING")
    payment_state: Mapped[str] = mapped_column(String(60), default="NOT_DUE")
    evidence_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class CommercialAuditEvent(Base):
    __tablename__ = "commercial_audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor: Mapped[str] = mapped_column(String(320))
    action: Mapped[str] = mapped_column(String(100), index=True)
    entity_type: Mapped[str] = mapped_column(String(80))
    entity_id: Mapped[str] = mapped_column(String(80))
    details_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class RelationshipClaimCheck(Base):
    __tablename__ = "relationship_claim_checks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preparation_id: Mapped[int] = mapped_column(ForeignKey("introduction_preparations.id"), index=True)
    party_a_reference: Mapped[str] = mapped_column(String(250))
    party_b_reference: Mapped[str] = mapped_column(String(250))
    checked_by: Mapped[str] = mapped_column(String(320))
    prior_relationship_found: Mapped[bool] = mapped_column(Boolean, default=False)
    claimant_reference: Mapped[str | None] = mapped_column(String(250), nullable=True)
    evidence_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    decision: Mapped[str] = mapped_column(String(60), default="CLEAR")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class PrivacyRequest(Base):
    __tablename__ = "privacy_requests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    request_type: Mapped[str] = mapped_column(String(60), index=True)
    subject_reference: Mapped[str] = mapped_column(String(250), index=True)
    requester_email: Mapped[str | None] = mapped_column(String(320), nullable=True)
    jurisdiction: Mapped[str | None] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(60), default="OPEN", index=True)
    identity_verification_state: Mapped[str] = mapped_column(String(60), default="PENDING")
    assigned_to: Mapped[str | None] = mapped_column(String(320), nullable=True)
    response_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class RetentionRule(Base):
    __tablename__ = "retention_rules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    record_class: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    retention_days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    deletion_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    legal_hold_override: Mapped[bool] = mapped_column(Boolean, default=True)
    owner_email: Mapped[str] = mapped_column(String(320))
    status: Mapped[str] = mapped_column(String(40), default="DRAFT")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class LegalHold(Base):
    __tablename__ = "legal_holds"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    hold_reference: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    scope: Mapped[str] = mapped_column(Text)
    reason: Mapped[str] = mapped_column(Text)
    owner_email: Mapped[str] = mapped_column(String(320))
    status: Mapped[str] = mapped_column(String(40), default="ACTIVE", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    released_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class SecurityEvent(Base):
    __tablename__ = "security_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    severity: Mapped[str] = mapped_column(String(30), index=True)
    actor_or_subject: Mapped[str | None] = mapped_column(String(320), nullable=True)
    source_ip: Mapped[str | None] = mapped_column(String(80), nullable=True)
    details_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(40), default="OPEN")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

class WorkerHeartbeat(Base):
    __tablename__ = "worker_heartbeats"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    worker_name: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default="HEALTHY")
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    details: Mapped[str | None] = mapped_column(Text, nullable=True)

class BackupStatus(Base):
    __tablename__ = "backup_status"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    backup_type: Mapped[str] = mapped_column(String(80), index=True)
    backup_reference: Mapped[str] = mapped_column(Text)
    completed_at: Mapped[datetime] = mapped_column(DateTime)
    verified_restore: Mapped[bool] = mapped_column(Boolean, default=False)
    verification_reference: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class AuditIntegrityCheckpoint(Base):
    __tablename__ = "audit_integrity_checkpoints"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    checkpoint_scope: Mapped[str] = mapped_column(String(120))
    record_count: Mapped[int] = mapped_column(Integer)
    digest: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
