import hashlib, re

def clean(v):
    return re.sub(r"\s+"," ",(v or "").strip().lower())

def fingerprint(title, geography=None, sector=None, source_object_id=None):
    raw="|".join([clean(title),clean(geography),clean(sector),clean(source_object_id)])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
