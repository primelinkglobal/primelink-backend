import json, time
from app.core.config import settings
from app.connectors.registry import get_connector
from app.discovery.normalization import fingerprint
from app.models.entities import (
    DiscoverySource, DiscoveryRun, DiscoveredCandidate,
    ConnectorHealthCheck, DiscoveryAuditEvent
)

def approved_sources(db):
    return db.query(DiscoverySource).filter(
        DiscoverySource.enabled == True,
        DiscoverySource.terms_permission_status == "APPROVED",
        DiscoverySource.status.in_(["APPROVED","WATCH"])
    ).all()

def run_discovery(db, mandate, actor):
    if not settings.external_discovery_enabled:
        raise RuntimeError("External discovery kill switch is OFF")

    sources=approved_sources(db)
    query={
        "objective":mandate.objective,
        "geography":mandate.geography,
        "sector":mandate.sector,
        "ticket_min":mandate.ticket_min,
        "ticket_max":mandate.ticket_max,
        "constraints":mandate.constraints,
    }
    run=DiscoveryRun(
        mandate_id=mandate.id, requested_by=actor, source_count=len(sources),
        result_count=0, status="RUNNING", query_json=json.dumps(query)
    )
    db.add(run); db.commit(); db.refresh(run)

    total=0
    for src in sources:
        connector=get_connector(src.source_key)
        started=time.time()
        health=connector.health()
        latency=(time.time()-started)*1000
        decision="CONTINUE" if all([
            health.get("reachable"),
            health.get("provenance_working"),
            health.get("scope_enforced")
        ]) else "DISABLE_OR_REVIEW"

        db.add(ConnectorHealthCheck(
            source_id=src.id,
            reachable=bool(health.get("reachable")),
            provenance_working=bool(health.get("provenance_working")),
            scope_enforced=bool(health.get("scope_enforced")),
            latency_ms=latency, error_rate=None, decision=decision,
            details=health.get("details")
        ))
        if decision != "CONTINUE":
            continue

        results=connector.search(query, limit=settings.discovery_max_results_per_source)
        for r in results:
            if not r.provenance:
                continue
            fp=fingerprint(r.title,r.geography,r.sector,r.source_object_id)
            existing=db.query(DiscoveredCandidate).filter(
                DiscoveredCandidate.normalized_fingerprint==fp
            ).first()
            row=DiscoveredCandidate(
                discovery_run_id=run.id, source_id=src.id,
                source_object_id=r.source_object_id, canonical_url=r.canonical_url,
                title=r.title, opportunity_type=r.opportunity_type,
                geography=r.geography, sector=r.sector, value=r.value,
                summary=r.summary, provenance_json=json.dumps(r.provenance),
                retrieved_at=r.retrieved_at,
                verification_state=settings.discovery_default_verification_state,
                review_state="PENDING",
                normalized_fingerprint=fp,
                duplicate_of_id=existing.id if existing else None
            )
            db.add(row); total += 1

    run.result_count=total
    run.status="COMPLETED"
    db.add(DiscoveryAuditEvent(
        actor=actor, action="DISCOVERY_RUN", source_id=None,
        entity_type="mandate", entity_id=str(mandate.id),
        details_json=json.dumps({"run_id":run.id,"source_count":len(sources),"result_count":total})
    ))
    db.commit()
    return run
