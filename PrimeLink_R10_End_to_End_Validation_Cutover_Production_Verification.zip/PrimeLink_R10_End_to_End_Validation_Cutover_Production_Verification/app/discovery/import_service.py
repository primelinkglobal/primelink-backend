import json
from app.models.entities import DiscoveredCandidate, Opportunity, DiscoveryAuditEvent

def import_candidate(db, candidate: DiscoveredCandidate, actor: str):
    if candidate.review_state != "APPROVED_FOR_IMPORT":
        raise ValueError("Candidate must be human-approved for import.")
    provenance=json.loads(candidate.provenance_json or "{}")
    if not provenance:
        raise ValueError("Provenance required.")
    if candidate.imported_opportunity_id:
        return db.get(Opportunity,candidate.imported_opportunity_id)

    opp=Opportunity(
        title=candidate.title,
        opportunity_type=candidate.opportunity_type or "External Opportunity",
        geography=candidate.geography or "Unknown",
        sector=candidate.sector or "Unknown",
        value=candidate.value,
        stage="SUBMITTED",
        source=f"external:{candidate.source_id}",
        provenance=json.dumps(provenance),
        verification_state="DISCOVERED_UNVERIFIED"
    )
    db.add(opp); db.commit(); db.refresh(opp)
    candidate.imported_opportunity_id=opp.id
    db.add(DiscoveryAuditEvent(
        actor=actor, action="IMPORT_DISCOVERED_CANDIDATE",
        source_id=candidate.source_id, entity_type="opportunity", entity_id=str(opp.id),
        details_json=json.dumps({"candidate_id":candidate.id})
    ))
    db.commit()
    return opp
