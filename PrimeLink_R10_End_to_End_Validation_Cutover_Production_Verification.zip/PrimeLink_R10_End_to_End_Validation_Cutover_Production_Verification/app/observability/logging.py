import logging, structlog
from app.core.config import settings

def configure_logging():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    if settings.structured_logging_enabled:
        structlog.configure(
            processors=[
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.processors.add_log_level,
                structlog.processors.JSONRenderer()
            ]
        )

logger = structlog.get_logger("primelink")
