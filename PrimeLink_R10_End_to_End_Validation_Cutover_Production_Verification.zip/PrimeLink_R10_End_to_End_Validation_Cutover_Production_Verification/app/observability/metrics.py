from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

REQUESTS=Counter("primelink_http_requests_total","HTTP requests",["method","path","status"])
LATENCY=Histogram("primelink_http_request_duration_seconds","HTTP latency",["method","path"])
OPEN_SECURITY_EVENTS=Gauge("primelink_open_security_events","Open security events",["severity"])
PENDING_WORKFLOW_EVENTS=Gauge("primelink_pending_workflow_events","Pending workflow events")
PENDING_NOTIFICATIONS=Gauge("primelink_pending_notifications","Pending notifications")
DISCOVERY_SOURCE_HEALTH=Gauge("primelink_discovery_source_health","Discovery source health",["source_id"])

def render_metrics():
    return generate_latest(), CONTENT_TYPE_LATEST
