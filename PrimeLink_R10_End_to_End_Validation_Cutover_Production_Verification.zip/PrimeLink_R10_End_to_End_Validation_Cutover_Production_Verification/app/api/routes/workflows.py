from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.deps import current_user
from app.db.session import get_db
from app.models.entities import (
    Opportunity, OpportunityActivity, CRMActivity, Task, ReviewDecision,
    WorkflowEvent, NotificationOutbox, IntroductionPreparation, MatchRecord, Participant
)
from app.schemas.d3 import (
    OpportunityTransitionIn, CRMActivityIn, TaskIn, TaskStatusIn,
    ReviewDecisionIn, IntroductionPreparationIn, IntroductionGateUpdate
)
from app.services.audit import record
from app.services.workflow_service import enqueue_event
from app.workflows.opportunity_lifecycle import can_transition
from app.workflows.automation_rules import events_for_opportunity_transition

router = APIRouter(prefix="/api/v1", tags=["workflow"])

@router.post("/opportunities/{opportunity_id}/transition")
def transition_opportunity(opportunity_id:int, body:OpportunityTransitionIn,
                           db:Session=Depends(get_db), user=Depends(current_user)):
    opp=db.get(Opportunity,opportunity_id)
    if not opp:
        raise HTTPException(404,"Opportunity not found")
    old=opp.stage
    if not can_transition(old, body.to_state):
        raise HTTPException(409,f"Transition {old} -> {body.to_state} is not allowed")
    opp.stage=body.to_state
    db.add(OpportunityActivity(
        opportunity_id=opp.id, actor_email=user.email, activity_type="STATE_CHANGE",
        from_state=old,to_state=body.to_state,note=body.note
    ))
    db.commit()
    for event_type in events_for_opportunity_transition(old, body.to_state):
        enqueue_event(db,event_type,"opportunity",opp.id,{"owner_email":user.email})
    record(db,user.email,"OPPORTUNITY_TRANSITION","opportunity",opp.id,f"{old}->{body.to_state}")
    return {"id":opp.id,"from":old,"to":opp.stage}

@router.get("/opportunities/{opportunity_id}/timeline")
def opportunity_timeline(opportunity_id:int, db:Session=Depends(get_db), user=Depends(current_user)):
    rows=db.query(OpportunityActivity).filter(OpportunityActivity.opportunity_id==opportunity_id).order_by(OpportunityActivity.created_at).all()
    return [{
        "id":r.id,"type":r.activity_type,"from":r.from_state,"to":r.to_state,
        "note":r.note,"actor":r.actor_email,"created_at":r.created_at
    } for r in rows]

@router.post("/crm/activities")
def create_crm_activity(body:CRMActivityIn, db:Session=Depends(get_db), user=Depends(current_user)):
    if not db.get(Participant,body.participant_id):
        raise HTTPException(404,"Participant not found")
    row=CRMActivity(owner_email=user.email,**body.model_dump(exclude={"owner_email"}))
    db.add(row); db.commit(); db.refresh(row)
    record(db,user.email,"CRM_ACTIVITY","participant",body.participant_id,body.activity_type)
    return {"id":row.id}

@router.get("/crm/participants/{participant_id}/timeline")
def crm_timeline(participant_id:int, db:Session=Depends(get_db), user=Depends(current_user)):
    rows=db.query(CRMActivity).filter(CRMActivity.participant_id==participant_id).order_by(CRMActivity.created_at.desc()).all()
    return [{
        "id":r.id,"activity_type":r.activity_type,"channel":r.channel,
        "subject":r.subject,"note":r.note,"next_action_at":r.next_action_at,
        "owner":r.owner_email,"created_at":r.created_at
    } for r in rows]

@router.post("/tasks")
def create_task(body:TaskIn, db:Session=Depends(get_db), user=Depends(current_user)):
    row=Task(**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    record(db,user.email,"CREATE","task",row.id)
    return {"id":row.id,"status":row.status}

@router.patch("/tasks/{task_id}/status")
def update_task(task_id:int, body:TaskStatusIn, db:Session=Depends(get_db), user=Depends(current_user)):
    row=db.get(Task,task_id)
    if not row: raise HTTPException(404,"Task not found")
    row.status=body.status
    if body.status=="DONE": row.completed_at=datetime.utcnow()
    db.commit()
    record(db,user.email,"TASK_STATUS","task",row.id,body.status)
    return {"id":row.id,"status":row.status}

@router.get("/tasks")
def list_tasks(status:str|None=None, db:Session=Depends(get_db), user=Depends(current_user)):
    q=db.query(Task)
    if status: q=q.filter(Task.status==status)
    rows=q.order_by(Task.created_at.desc()).limit(200).all()
    return [{"id":r.id,"title":r.title,"type":r.task_type,"owner":r.owner_email,
             "status":r.status,"priority":r.priority,"due_at":r.due_at,
             "entity_type":r.entity_type,"entity_id":r.entity_id} for r in rows]

@router.post("/reviews")
def create_review(body:ReviewDecisionIn, db:Session=Depends(get_db), user=Depends(current_user)):
    row=ReviewDecision(reviewer_email=user.email,**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    record(db,user.email,"REVIEW_DECISION",body.entity_type,body.entity_id,body.decision)
    return {"id":row.id,"decision":row.decision}

@router.post("/introduction-preparations")
def create_intro_prep(body:IntroductionPreparationIn, db:Session=Depends(get_db), user=Depends(current_user)):
    if not db.get(MatchRecord,body.match_id):
        raise HTTPException(404,"Match not found")
    row=IntroductionPreparation(**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"status":row.status}

@router.patch("/introduction-preparations/{prep_id}")
def update_intro_prep(prep_id:int, body:IntroductionGateUpdate,
                      db:Session=Depends(get_db), user=Depends(current_user)):
    row=db.get(IntroductionPreparation,prep_id)
    if not row: raise HTTPException(404,"Introduction preparation not found")
    for k,v in body.model_dump(exclude_none=True).items():
        setattr(row,k,v)
    row.updated_at=datetime.utcnow()
    all_ready=all([
        row.human_review_complete,row.verification_complete,
        row.compliance_gate_passed,row.counterparty_consent_complete
    ])
    row.status="READY_FOR_AUTHORIZED_INTRODUCTION" if all_ready else "PREPARATION"
    db.commit()
    record(db,user.email,"INTRO_PREP_UPDATE","introduction_preparation",row.id,row.status)
    return {"id":row.id,"status":row.status,
            "automatic_introduction":False,
            "notice":"Ready status does not send an introduction automatically."}

@router.get("/workflow-events")
def workflow_events(status:str|None=None, db:Session=Depends(get_db), user=Depends(current_user)):
    q=db.query(WorkflowEvent)
    if status: q=q.filter(WorkflowEvent.status==status)
    rows=q.order_by(WorkflowEvent.created_at.desc()).limit(200).all()
    return [{"id":r.id,"event_type":r.event_type,"entity_type":r.entity_type,
             "entity_id":r.entity_id,"status":r.status,"attempts":r.attempts,
             "last_error":r.last_error} for r in rows]

@router.get("/notifications/outbox")
def notification_outbox(status:str|None=None, db:Session=Depends(get_db), user=Depends(current_user)):
    q=db.query(NotificationOutbox)
    if status: q=q.filter(NotificationOutbox.status==status)
    rows=q.order_by(NotificationOutbox.created_at.desc()).limit(200).all()
    return [{"id":r.id,"recipient":r.recipient,"channel":r.channel,
             "template_key":r.template_key,"status":r.status,"attempts":r.attempts} for r in rows]
