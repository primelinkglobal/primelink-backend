import json
from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel,Field
from sqlalchemy.orm import Session
from app.api.deps import current_user
from app.db.session import get_db
from app.models.entities import (
    Mandate, DiscoverySource, DiscoveryRun, DiscoveredCandidate,
    ConnectorHealthCheck, DiscoveryAuditEvent
)
from app.discovery.service import run_discovery
from app.discovery.import_service import import_candidate

router=APIRouter(prefix="/api/v1/discovery",tags=["discovery"])

class SourceIn(BaseModel):
    source_key:str
    name:str
    source_type:str
    purpose:str
    approved_scope:str
    terms_permission_status:str=Field(pattern="^(PENDING_REVIEW|APPROVED|RESTRICTED|REJECTED)$")
    provenance_method:str
    owner_email:str
    enabled:bool=False
    status:str=Field(default="WATCH",pattern="^(APPROVED|WATCH|RESTRICTED|DISABLED)$")

class ReviewIn(BaseModel):
    decision:str=Field(pattern="^(APPROVED_FOR_IMPORT|REJECTED|NEEDS_REVIEW|DUPLICATE)$")
    note:str|None=None

@router.post("/sources")
def create_source(body:SourceIn,db:Session=Depends(get_db),user=Depends(current_user)):
    if user.role!="admin": raise HTTPException(403,"Admin required")
    if db.query(DiscoverySource).filter(DiscoverySource.source_key==body.source_key).first():
        raise HTTPException(409,"Source already exists")
    row=DiscoverySource(**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"source_key":row.source_key,"enabled":row.enabled,"status":row.status}

@router.get("/sources")
def list_sources(db:Session=Depends(get_db),user=Depends(current_user)):
    rows=db.query(DiscoverySource).order_by(DiscoverySource.name).all()
    return [{"id":r.id,"source_key":r.source_key,"name":r.name,
             "terms_permission_status":r.terms_permission_status,
             "enabled":r.enabled,"status":r.status,"owner_email":r.owner_email} for r in rows]

@router.post("/mandates/{mandate_id}/run")
def run_for_mandate(mandate_id:int,db:Session=Depends(get_db),user=Depends(current_user)):
    m=db.get(Mandate,mandate_id)
    if not m: raise HTTPException(404,"Mandate not found")
    try: run=run_discovery(db,m,user.email)
    except RuntimeError as e: raise HTTPException(503,str(e))
    return {"run_id":run.id,"source_count":run.source_count,"result_count":run.result_count,"status":run.status}

@router.get("/runs/{run_id}/results")
def results(run_id:int,db:Session=Depends(get_db),user=Depends(current_user)):
    rows=db.query(DiscoveredCandidate).filter(
        DiscoveredCandidate.discovery_run_id==run_id
    ).order_by(DiscoveredCandidate.created_at.desc()).all()
    return [{
        "candidate_id":r.id,"title":r.title,"geography":r.geography,"sector":r.sector,
        "verification_state":r.verification_state,"review_state":r.review_state,
        "duplicate_of_id":r.duplicate_of_id,"imported_opportunity_id":r.imported_opportunity_id,
        "provenance":json.loads(r.provenance_json or "{}")
    } for r in rows]

@router.post("/candidates/{candidate_id}/review")
def review(candidate_id:int,body:ReviewIn,db:Session=Depends(get_db),user=Depends(current_user)):
    c=db.get(DiscoveredCandidate,candidate_id)
    if not c: raise HTTPException(404,"Candidate not found")
    c.review_state=body.decision
    db.add(DiscoveryAuditEvent(
        actor=user.email,action="HUMAN_DISCOVERY_REVIEW",source_id=c.source_id,
        entity_type="discovered_candidate",entity_id=str(c.id),
        details_json=json.dumps({"decision":body.decision,"note":body.note})
    ))
    db.commit()
    return {"candidate_id":c.id,"review_state":c.review_state}

@router.post("/candidates/{candidate_id}/import")
def import_to_opportunity(candidate_id:int,db:Session=Depends(get_db),user=Depends(current_user)):
    c=db.get(DiscoveredCandidate,candidate_id)
    if not c: raise HTTPException(404,"Candidate not found")
    try: opp=import_candidate(db,c,user.email)
    except ValueError as e: raise HTTPException(409,str(e))
    return {"opportunity_id":opp.id,"verification_state":opp.verification_state,
            "notice":"Imported external opportunity remains unverified."}

@router.get("/health")
def connector_health(db:Session=Depends(get_db),user=Depends(current_user)):
    rows=db.query(ConnectorHealthCheck).order_by(ConnectorHealthCheck.created_at.desc()).limit(100).all()
    return [{"source_id":r.source_id,"reachable":r.reachable,
             "provenance_working":r.provenance_working,"scope_enforced":r.scope_enforced,
             "latency_ms":r.latency_ms,"decision":r.decision,"created_at":r.created_at} for r in rows]
