from fastapi import APIRouter,Depends,HTTPException,Response
from pydantic import BaseModel,Field
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.deps import current_user
from app.models.entities import SecurityEvent,WorkerHeartbeat,BackupStatus,WorkflowEvent,NotificationOutbox
from app.services.security_monitoring import record_security_event,audit_integrity_checkpoint,backup_freshness
from app.observability.metrics import render_metrics,PENDING_WORKFLOW_EVENTS,PENDING_NOTIFICATIONS,OPEN_SECURITY_EVENTS
from app.core.config import settings

router=APIRouter(tags=["monitoring"])

class SecurityEventIn(BaseModel):
    event_type:str
    severity:str=Field(pattern="^(LOW|MEDIUM|HIGH|CRITICAL)$")
    actor_or_subject:str|None=None
    details:dict={}

class BackupIn(BaseModel):
    backup_type:str
    backup_reference:str
    completed_at:str
    verified_restore:bool=False
    verification_reference:str|None=None

@router.get("/metrics",include_in_schema=False)
def metrics(db:Session=Depends(get_db)):
    PENDING_WORKFLOW_EVENTS.set(db.query(WorkflowEvent).filter(WorkflowEvent.status=="PENDING").count())
    PENDING_NOTIFICATIONS.set(db.query(NotificationOutbox).filter(NotificationOutbox.status=="PENDING").count())
    for sev in ["LOW","MEDIUM","HIGH","CRITICAL"]:
        OPEN_SECURITY_EVENTS.labels(sev).set(
            db.query(SecurityEvent).filter(SecurityEvent.status=="OPEN",SecurityEvent.severity==sev).count()
        )
    data,ctype=render_metrics()
    return Response(content=data,media_type=ctype)

@router.post("/api/v1/security/events")
def create_security_event(body:SecurityEventIn,db:Session=Depends(get_db),user=Depends(current_user)):
    row=record_security_event(db,body.event_type,body.severity,user.email,None,body.details)
    return {"security_event_id":row.id,"status":row.status}

@router.post("/api/v1/security/audit-integrity-checkpoint")
def checkpoint(db:Session=Depends(get_db),user=Depends(current_user)):
    if user.role!="admin": raise HTTPException(403,"Admin required")
    row=audit_integrity_checkpoint(db)
    return {"checkpoint_id":row.id,"record_count":row.record_count,"digest":row.digest}

@router.get("/api/v1/operations/health-summary")
def health_summary(db:Session=Depends(get_db),user=Depends(current_user)):
    backup=backup_freshness(db,settings.backup_freshness_hours)
    return {
        "open_critical_security_events":db.query(SecurityEvent).filter(
            SecurityEvent.status=="OPEN",SecurityEvent.severity=="CRITICAL").count(),
        "pending_workflow_events":db.query(WorkflowEvent).filter(WorkflowEvent.status=="PENDING").count(),
        "pending_notifications":db.query(NotificationOutbox).filter(NotificationOutbox.status=="PENDING").count(),
        "worker_heartbeats":db.query(WorkerHeartbeat).count(),
        "backup":backup
    }
