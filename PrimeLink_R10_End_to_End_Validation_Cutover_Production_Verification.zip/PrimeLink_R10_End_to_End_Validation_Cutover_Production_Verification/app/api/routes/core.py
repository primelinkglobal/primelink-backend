from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.deps import current_user
from app.models.entities import Participant, Mandate, Opportunity, MatchRecord, CommercialCase, Task, CRMActivity, WorkflowEvent
from app.services.matching import score_match
from app.services.audit import record
from app.core.config import settings

router = APIRouter(prefix="/api/v1", tags=["core"])

class ParticipantIn(BaseModel):
    participant_type: str
    name: str
    organization: str | None = None
    geography: str | None = None

class MandateIn(BaseModel):
    participant_id: int
    objective: str
    geography: str
    sector: str
    ticket_min: float | None = None
    ticket_max: float | None = None
    constraints: str | None = None

class OpportunityIn(BaseModel):
    title: str
    opportunity_type: str
    geography: str
    sector: str
    value: float | None = None
    source: str
    provenance: str | None = None

@router.get("/dashboard")
def dashboard(db: Session=Depends(get_db), user=Depends(current_user)):
    return {
        "participants":db.query(Participant).count(),
        "mandates":db.query(Mandate).count(),
        "opportunities":db.query(Opportunity).count(),
        "matches":db.query(MatchRecord).count(),
        "commercial_cases":db.query(CommercialCase).count(),
        "open_tasks":db.query(Task).filter(Task.status!="DONE").count(),
        "crm_activities":db.query(CRMActivity).count(),
        "pending_workflow_events":db.query(WorkflowEvent).filter(WorkflowEvent.status=="PENDING").count(),
        "implementation_state":"IMPLEMENTED_BASELINE"
    }

@router.post("/participants")
def create_participant(body: ParticipantIn, db: Session=Depends(get_db), user=Depends(current_user)):
    x=Participant(**body.model_dump()); db.add(x); db.commit(); db.refresh(x)
    record(db,user.email,"CREATE","participant",x.id)
    return {"id":x.id,"status":x.status}

@router.post("/mandates")
def create_mandate(body: MandateIn, db: Session=Depends(get_db), user=Depends(current_user)):
    if not db.get(Participant, body.participant_id): raise HTTPException(404,"Participant not found")
    x=Mandate(**body.model_dump()); db.add(x); db.commit(); db.refresh(x)
    record(db,user.email,"CREATE","mandate",x.id)
    return {"id":x.id,"freshness":x.freshness}

@router.post("/opportunities")
def create_opportunity(body: OpportunityIn, db: Session=Depends(get_db), user=Depends(current_user)):
    if not body.provenance and body.source.lower() not in {"internal","direct submission"}:
        raise HTTPException(422,"External/non-direct opportunities require provenance")
    x=Opportunity(**body.model_dump()); db.add(x); db.commit(); db.refresh(x)
    record(db,user.email,"CREATE","opportunity",x.id)
    return {"id":x.id,"verification_state":x.verification_state}

@router.post("/match/{mandate_id}/{opportunity_id}")
def match(mandate_id:int, opportunity_id:int, db:Session=Depends(get_db), user=Depends(current_user)):
    if not settings.ai_matching_enabled: raise HTTPException(503,"AI matching disabled")
    m=db.get(Mandate,mandate_id); o=db.get(Opportunity,opportunity_id)
    if not m or not o: raise HTTPException(404,"Mandate or opportunity not found")
    score, explanation=score_match(m,o)
    x=MatchRecord(mandate_id=m.id,opportunity_id=o.id,score=score,explanation=explanation)
    db.add(x); db.commit(); db.refresh(x)
    record(db,user.email,"MATCH","match_record",x.id,explanation)
    return {"match_id":x.id,"score":score,"explanation":explanation,
            "human_review_state":x.human_review_state,
            "notice":"Match score is prioritization only; it is not verification or introduction authorization."}
