from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import User, LoginEvent
from app.core.security import verify_password, create_access_token, hash_password
from app.services.auth_service import issue_db_token, consume_token, revoke_user_tokens
from app.services.mailer import send_email
from app.core.config import settings
from app.security.rate_limit import limiter

router = APIRouter(prefix="/auth", tags=["auth"])

class Login(BaseModel):
    email: EmailStr
    password: str

class TokenIn(BaseModel):
    token: str

class PasswordRequest(BaseModel):
    email: EmailStr

class PasswordReset(BaseModel):
    token: str
    new_password: str = Field(min_length=12, max_length=200)

def _login_event(db, request, email, success):
    db.add(LoginEvent(
        email=email, success=success,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    ))
    db.commit()

@router.post("/login")
@limiter.limit(settings.login_rate_limit)
def login(body: Login, request: Request, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email).first()
    if not user or not user.active or not verify_password(body.password, user.password_hash):
        _login_event(db, request, body.email, False)
        raise HTTPException(401, "Invalid credentials")
    _login_event(db, request, body.email, True)
    refresh = issue_db_token(db, user, "REFRESH", timedelta(days=settings.refresh_token_days))
    return {
        "access_token": create_access_token(user.email, user.role),
        "refresh_token": refresh,
        "token_type":"bearer"
    }

@router.post("/refresh")
def refresh(body: TokenIn, db: Session = Depends(get_db)):
    rec = consume_token(db, body.token, "REFRESH")
    if not rec:
        raise HTTPException(401, "Invalid or expired refresh token")
    user = db.get(User, rec.user_id)
    if not user or not user.active:
        raise HTTPException(401, "User unavailable")
    new_refresh = issue_db_token(db, user, "REFRESH", timedelta(days=settings.refresh_token_days))
    return {
        "access_token": create_access_token(user.email, user.role),
        "refresh_token": new_refresh,
        "token_type":"bearer"
    }

@router.post("/password-reset/request")
def request_reset(body: PasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email).first()
    if user and user.active:
        raw = issue_db_token(db, user, "RESET", timedelta(minutes=settings.password_reset_minutes))
        send_email(
            user.email,
            "PrimeLink password reset",
            f"Use this token to reset your password: {raw}"
        )
    # non-enumerating response
    return {"status":"accepted"}

@router.post("/password-reset/confirm")
def confirm_reset(body: PasswordReset, db: Session = Depends(get_db)):
    rec = consume_token(db, body.token, "RESET")
    if not rec:
        raise HTTPException(400, "Invalid or expired reset token")
    user = db.get(User, rec.user_id)
    user.password_hash = hash_password(body.new_password)
    db.commit()
    revoke_user_tokens(db, user.id, "REFRESH")
    return {"status":"password_updated"}

@router.post("/logout-all")
def logout_all(body: PasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email).first()
    if user:
        revoke_user_tokens(db, user.id, "REFRESH")
    return {"status":"accepted"}
