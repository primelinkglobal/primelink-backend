import json
from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel,Field
from sqlalchemy.orm import Session
from app.api.deps import current_user
from app.db.session import get_db
from app.models.entities import Mandate,AIMatchCandidate,AIAuditEvent
from app.ai.engine import run_intelligence,MODEL_VERSION

router=APIRouter(prefix="/api/v1/intelligence",tags=["intelligence"])
class ReviewIn(BaseModel):
    decision:str=Field(pattern="^(ACCEPTED|REJECTED|NEEDS_REVIEW)$")
    note:str|None=None

@router.post("/mandates/{mandate_id}/run")
def run(mandate_id:int,limit:int=50,db:Session=Depends(get_db),user=Depends(current_user)):
    m=db.get(Mandate,mandate_id)
    if not m: raise HTTPException(404,"Mandate not found")
    try: runrow,rows=run_intelligence(db,m,user.email,min(max(limit,1),200))
    except RuntimeError as e: raise HTTPException(503,str(e))
    return {"run_id":runrow.id,"model_version":runrow.model_version,
      "candidates":[{"candidate_id":r.id,"opportunity_id":r.opportunity_id,
      "score":r.final_score,"structured_score":r.structured_score,
      "semantic_score":r.semantic_score,"explanation":r.explanation,
      "human_review_state":r.human_review_state} for r in rows],
      "notice":"AI ranking is decision support only. It does not verify opportunities or authorize introductions."}

@router.post("/candidates/{candidate_id}/review")
def review(candidate_id:int,body:ReviewIn,db:Session=Depends(get_db),user=Depends(current_user)):
    c=db.get(AIMatchCandidate,candidate_id)
    if not c: raise HTTPException(404,"Candidate not found")
    c.human_review_state=body.decision
    db.add(AIAuditEvent(actor=user.email,action="HUMAN_REVIEW",model_version=MODEL_VERSION,
      entity_type="ai_match_candidate",entity_id=str(c.id),
      details_json=json.dumps({"decision":body.decision,"note":body.note})))
    db.commit()
    return {"candidate_id":c.id,"human_review_state":c.human_review_state}

@router.get("/runs/{run_id}")
def get_run(run_id:int,db:Session=Depends(get_db),user=Depends(current_user)):
    rows=db.query(AIMatchCandidate).filter(AIMatchCandidate.run_id==run_id).order_by(AIMatchCandidate.final_score.desc()).all()
    return [{"candidate_id":r.id,"opportunity_id":r.opportunity_id,"score":r.final_score,
             "explanation":r.explanation,"human_review_state":r.human_review_state,
             "evidence":json.loads(r.evidence_json or "{}")} for r in rows]
