import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from app.api.deps import current_user
from app.db.session import get_db
from app.models.entities import (
    OnboardingApplication, Participant, AgreementRecord, IntroductionPreparation,
    ProtectedIntroduction, PriorRelationshipCheck, RelationshipClaimCheck, CommercialCase, FeeEvent,
    InvoiceRecord, CollectionRecord, ReferralAllocation, CommercialAuditEvent
)
from app.onboarding.service import review_application
from app.commercial.gates import introduction_gate, fee_event_gate, invoice_gate
from app.commercial.reconciliation import reconcile

router=APIRouter(prefix="/api/v1/commercial",tags=["commercial"])

class OnboardingIn(BaseModel):
    participant_type:str
    applicant_name:str
    organization:str|None=None
    email:EmailStr
    geography:str|None=None
    sectors:list[str]=[]
    source:str|None=None
    profile:dict={}
    terms_accepted:bool=False
    verification_required:bool=True

class ApplicationReviewIn(BaseModel):
    decision:str=Field(pattern="^(APPROVE|APPROVE_WITH_RESTRICTIONS|HOLD|REJECT)$")
    reason:str|None=None
    verification_state:str|None=None

class AgreementIn(BaseModel):
    agreement_type:str
    agreement_reference:str
    party_a:str
    party_b:str
    participant_id:int|None=None
    effective_date:datetime|None=None
    expiry_date:datetime|None=None
    fee_mechanism:str|None=None
    fee_trigger:str|None=None
    payment_terms:str|None=None
    referral_allocation_terms:str|None=None
    version_label:str="1.0"
    status:str=Field(default="DRAFT",pattern="^(DRAFT|ACTIVE|SUSPENDED|EXPIRED|TERMINATED)$")
    record_location:str|None=None

class PriorCheckIn(BaseModel):
    prior_relationship_found:bool=False
    prior_claimant:str|None=None
    evidence_reference:str|None=None
    decision:str=Field(default="CLEAR",pattern="^(CLEAR|CONFLICT|ESCALATE)$")

class IntroductionAuthorizeIn(BaseModel):
    preparation_id:int
    agreement_id:int
    party_a_reference:str
    party_b_reference:str
    channel:str
    introduction_reference:str|None=None
    prior_relationship_check_id:int

class CommercialCaseIn(BaseModel):
    opportunity_id:int|None=None
    agreement_reference:str|None=None
    commercial_state:str="QUALIFIED"
    fee_trigger:str|None=None
    currency:str|None=None
    amount_estimate:float|None=None

class FeeEventIn(BaseModel):
    commercial_case_id:int
    agreement_id:int
    introduction_id:int|None=None
    trigger_type:str
    trigger_date:datetime|None=None
    event_evidence:str|None=None
    calculation_basis:str|None=None
    currency:str|None=None
    amount:float|None=None
    duplicate_claim:bool=False

class ApprovalIn(BaseModel):
    decision:str=Field(pattern="^(APPROVED|REJECTED|ESCALATED)$")
    note:str|None=None

class InvoiceIn(BaseModel):
    invoice_reference:str
    bill_to:str
    due_date:datetime|None=None
    record_location:str|None=None

class CollectionIn(BaseModel):
    payer:str
    amount:float
    payment_reference:str

class ReferralAllocationIn(BaseModel):
    partner_participant_id:int
    governing_agreement_id:int
    calculation_basis:str
    amount:float
    evidence_reference:str|None=None

@router.post("/onboarding/applications")
def submit_application(body:OnboardingIn,db:Session=Depends(get_db)):
    row=OnboardingApplication(
        participant_type=body.participant_type,
        applicant_name=body.applicant_name,
        organization=body.organization,
        email=str(body.email),
        geography=body.geography,
        sectors=",".join(body.sectors),
        source=body.source,
        profile_json=json.dumps(body.profile),
        terms_accepted=body.terms_accepted,
        verification_required=body.verification_required,
        verification_state="PENDING" if body.verification_required else "NOT_REQUIRED",
        review_state="PENDING"
    )
    db.add(row); db.commit(); db.refresh(row)
    return {"application_id":row.id,"review_state":row.review_state,"verification_state":row.verification_state}

@router.post("/onboarding/applications/{application_id}/review")
def review_onboarding(application_id:int,body:ApplicationReviewIn,
                      db:Session=Depends(get_db),user=Depends(current_user)):
    row=db.get(OnboardingApplication,application_id)
    if not row: raise HTTPException(404,"Application not found")
    if body.verification_state:
        row.verification_state=body.verification_state
        db.commit()
    try:
        row=review_application(db,row,user.email,body.decision,body.reason)
    except ValueError as e:
        raise HTTPException(409,str(e))
    return {"application_id":row.id,"decision":row.review_state,"participant_id":row.participant_id}

@router.post("/agreements")
def create_agreement(body:AgreementIn,db:Session=Depends(get_db),user=Depends(current_user)):
    if user.role!="admin": raise HTTPException(403,"Admin required")
    row=AgreementRecord(owner_email=user.email,**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return {"agreement_id":row.id,"reference":row.agreement_reference,"status":row.status}

@router.post("/introductions/{preparation_id}/claim-check")
def create_claim_check(preparation_id:int,body:PriorCheckIn,
                       party_a_reference:str,party_b_reference:str,
                       db:Session=Depends(get_db),user=Depends(current_user)):
    prep=db.get(IntroductionPreparation,preparation_id)
    if not prep: raise HTTPException(404,"Introduction preparation not found")
    row=RelationshipClaimCheck(
        preparation_id=prep.id,
        party_a_reference=party_a_reference,
        party_b_reference=party_b_reference,
        checked_by=user.email,
        prior_relationship_found=body.prior_relationship_found,
        claimant_reference=body.prior_claimant,
        evidence_reference=body.evidence_reference,
        decision=body.decision
    )
    db.add(row); db.commit(); db.refresh(row)
    return {"claim_check_id":row.id,"decision":row.decision}

@router.post("/commercial-cases")
def create_case(body:CommercialCaseIn,db:Session=Depends(get_db),user=Depends(current_user)):
    row=CommercialCase(**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    db.add(CommercialAuditEvent(actor=user.email,action="CREATE_COMMERCIAL_CASE",
        entity_type="commercial_case",entity_id=str(row.id),details_json=None))
    db.commit()
    return {"commercial_case_id":row.id,"state":row.commercial_state}

@router.post("/introductions/authorize")
def authorize_introduction(body:IntroductionAuthorizeIn,
                           db:Session=Depends(get_db),user=Depends(current_user)):
    prep=db.get(IntroductionPreparation,body.preparation_id)
    agreement=db.get(AgreementRecord,body.agreement_id)
    if not prep: raise HTTPException(404,"Preparation not found")
    prior=db.get(RelationshipClaimCheck,body.prior_relationship_check_id)
    if not prior: raise HTTPException(404,"Relationship claim check not found")
    if prior.preparation_id != prep.id:
        raise HTTPException(409,"Claim check does not belong to this preparation")
    prior_clear=(prior.decision=="CLEAR")
    gate=introduction_gate(prep,agreement,prior_clear)
    if not gate["allowed"]:
        raise HTTPException(409,{"message":"Introduction gate failed","failures":gate["failures"]})

    row=ProtectedIntroduction(
        preparation_id=prep.id,
        match_id=prep.match_id,
        agreement_id=agreement.id,
        party_a_reference=body.party_a_reference,
        party_b_reference=body.party_b_reference,
        relationship_owner_email=prep.relationship_owner_email,
        authorized_by=user.email,
        channel=body.channel,
        introduction_reference=body.introduction_reference,
        prior_relationship_checked=True,
        compliance_gate_passed=prep.compliance_gate_passed,
        status="AUTHORIZED"
    )
    db.add(row); db.commit(); db.refresh(row)
    db.add(CommercialAuditEvent(actor=user.email,action="AUTHORIZE_INTRODUCTION",
        entity_type="protected_introduction",entity_id=str(row.id),
        details_json=json.dumps({"agreement_id":agreement.id,"preparation_id":prep.id})))
    db.commit()
    return {"introduction_id":row.id,"status":row.status,
            "notice":"Authorization record created. Delivery remains an explicit operator action."}

@router.post("/introductions/{introduction_id}/mark-delivered")
def mark_delivered(introduction_id:int,reference:str,
                   db:Session=Depends(get_db),user=Depends(current_user)):
    row=db.get(ProtectedIntroduction,introduction_id)
    if not row: raise HTTPException(404,"Introduction not found")
    if row.status!="AUTHORIZED": raise HTTPException(409,"Introduction is not in AUTHORIZED state")
    row.status="INTRODUCED"
    row.introduced_at=datetime.utcnow()
    row.introduction_reference=reference
    db.add(CommercialAuditEvent(actor=user.email,action="MARK_INTRODUCTION_DELIVERED",
        entity_type="protected_introduction",entity_id=str(row.id),
        details_json=json.dumps({"reference":reference})))
    db.commit()
    return {"introduction_id":row.id,"status":row.status}

@router.post("/introductions/{introduction_id}/prior-check")
def prior_check_for_intro(introduction_id:int,body:PriorCheckIn,
                          db:Session=Depends(get_db),user=Depends(current_user)):
    intro=db.get(ProtectedIntroduction,introduction_id)
    if not intro: raise HTTPException(404,"Introduction not found")
    row=PriorRelationshipCheck(
        introduction_id=intro.id,checked_by=user.email,
        prior_relationship_found=body.prior_relationship_found,
        prior_claimant=body.prior_claimant,
        evidence_reference=body.evidence_reference,
        decision=body.decision
    )
    db.add(row); db.commit(); db.refresh(row)
    return {"check_id":row.id,"decision":row.decision}

@router.post("/fee-events")
def create_fee_event(body:FeeEventIn,db:Session=Depends(get_db),user=Depends(current_user)):
    if not db.get(CommercialCase,body.commercial_case_id):
        raise HTTPException(404,"Commercial case not found")
    if not db.get(AgreementRecord,body.agreement_id):
        raise HTTPException(404,"Agreement not found")
    row=FeeEvent(**body.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return {"fee_event_id":row.id,"status":row.status,"approval_state":row.approval_state}

@router.post("/fee-events/{fee_event_id}/approve")
def approve_fee_event(fee_event_id:int,body:ApprovalIn,
                      db:Session=Depends(get_db),user=Depends(current_user)):
    row=db.get(FeeEvent,fee_event_id)
    if not row: raise HTTPException(404,"Fee event not found")
    if user.role!="admin": raise HTTPException(403,"Admin required")
    row.approval_state=body.decision
    agreement=db.get(AgreementRecord,row.agreement_id)
    gate=fee_event_gate(row,agreement)
    row.status="VALIDATED" if gate["validated"] else ("REJECTED" if body.decision=="REJECTED" else "PENDING")
    db.add(CommercialAuditEvent(actor=user.email,action="FEE_EVENT_REVIEW",
        entity_type="fee_event",entity_id=str(row.id),
        details_json=json.dumps({"decision":body.decision,"gate":gate,"note":body.note})))
    db.commit()
    return {"fee_event_id":row.id,"status":row.status,"gate":gate}

@router.post("/fee-events/{fee_event_id}/invoice")
def create_invoice(fee_event_id:int,body:InvoiceIn,
                   db:Session=Depends(get_db),user=Depends(current_user)):
    fee=db.get(FeeEvent,fee_event_id)
    if not fee: raise HTTPException(404,"Fee event not found")
    if not invoice_gate(fee): raise HTTPException(409,"Validated fee event with amount/currency required")
    row=InvoiceRecord(
        fee_event_id=fee.id,invoice_reference=body.invoice_reference,bill_to=body.bill_to,
        currency=fee.currency,amount=fee.amount,due_date=body.due_date,
        status="ISSUED",record_location=body.record_location
    )
    db.add(row); db.commit(); db.refresh(row)
    return {"invoice_id":row.id,"invoice_reference":row.invoice_reference,"status":row.status}

@router.post("/invoices/{invoice_id}/collections")
def record_collection(invoice_id:int,body:CollectionIn,
                      db:Session=Depends(get_db),user=Depends(current_user)):
    inv=db.get(InvoiceRecord,invoice_id)
    if not inv: raise HTTPException(404,"Invoice not found")
    if body.amount<=0: raise HTTPException(422,"Amount must be positive")
    row=CollectionRecord(invoice_id=inv.id,payer=body.payer,currency=inv.currency,
                         amount=body.amount,payment_reference=body.payment_reference)
    db.add(row)
    inv.paid_amount=float(inv.paid_amount or 0)+body.amount
    inv.status="PAID" if round(inv.paid_amount,2)>=round(inv.amount,2) else "PARTIALLY_PAID"
    db.commit(); db.refresh(row)
    return {"collection_id":row.id,"invoice_status":inv.status,"paid_amount":inv.paid_amount}

@router.get("/invoices/{invoice_id}/reconciliation")
def invoice_reconciliation(invoice_id:int,db:Session=Depends(get_db),user=Depends(current_user)):
    inv=db.get(InvoiceRecord,invoice_id)
    if not inv: raise HTTPException(404,"Invoice not found")
    rows=db.query(CollectionRecord).filter(CollectionRecord.invoice_id==invoice_id).all()
    result=reconcile(inv,rows)
    if result["reconciled"]:
        for c in rows: c.reconciled=True
        db.commit()
    return result

@router.post("/fee-events/{fee_event_id}/referral-allocations")
def create_allocation(fee_event_id:int,body:ReferralAllocationIn,
                      db:Session=Depends(get_db),user=Depends(current_user)):
    fee=db.get(FeeEvent,fee_event_id)
    if not fee or fee.status!="VALIDATED":
        raise HTTPException(409,"Validated fee event required")
    if not db.get(Participant,body.partner_participant_id):
        raise HTTPException(404,"Partner participant not found")
    agreement=db.get(AgreementRecord,body.governing_agreement_id)
    if not agreement or agreement.status!="ACTIVE":
        raise HTTPException(409,"Active governing agreement required")
    row=ReferralAllocation(
        fee_event_id=fee.id,
        partner_participant_id=body.partner_participant_id,
        governing_agreement_id=body.governing_agreement_id,
        calculation_basis=body.calculation_basis,
        currency=fee.currency or "",
        amount=body.amount,
        approval_state="PENDING",
        payment_state="NOT_DUE",
        evidence_reference=body.evidence_reference
    )
    db.add(row); db.commit(); db.refresh(row)
    return {"allocation_id":row.id,"approval_state":row.approval_state}

@router.get("/dashboard")
def commercial_dashboard(db:Session=Depends(get_db),user=Depends(current_user)):
    return {
        "onboarding_pending":db.query(OnboardingApplication).filter(OnboardingApplication.review_state=="PENDING").count(),
        "participants_active":db.query(Participant).filter(Participant.status=="ACTIVE").count(),
        "active_agreements":db.query(AgreementRecord).filter(AgreementRecord.status=="ACTIVE").count(),
        "protected_introductions":db.query(ProtectedIntroduction).count(),
        "fee_events_validated":db.query(FeeEvent).filter(FeeEvent.status=="VALIDATED").count(),
        "invoices_open":db.query(InvoiceRecord).filter(InvoiceRecord.status.in_(["ISSUED","PARTIALLY_PAID"])).count(),
        "allocations_pending":db.query(ReferralAllocation).filter(ReferralAllocation.approval_state=="PENDING").count()
    }
