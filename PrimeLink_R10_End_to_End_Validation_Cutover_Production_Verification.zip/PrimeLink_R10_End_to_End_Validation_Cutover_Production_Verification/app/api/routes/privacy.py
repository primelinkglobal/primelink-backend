from fastapi import APIRouter,Depends,HTTPException
from pydantic import BaseModel,EmailStr,Field
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.deps import current_user
from app.models.entities import PrivacyRequest,RetentionRule,LegalHold
from app.privacy.service import complete_privacy_request,can_delete_record

router=APIRouter(prefix="/api/v1/privacy",tags=["privacy"])

class PrivacyRequestIn(BaseModel):
    request_type:str=Field(pattern="^(ACCESS|CORRECTION|DELETION|RESTRICTION|EXPORT|OBJECTION|OTHER)$")
    subject_reference:str
    requester_email:EmailStr|None=None
    jurisdiction:str|None=None

class VerifyIn(BaseModel):
    state:str=Field(pattern="^(PENDING|VERIFIED|REJECTED)$")

class CompleteIn(BaseModel):
    response_reference:str

class RetentionRuleIn(BaseModel):
    record_class:str
    retention_days:int|None=None
    deletion_enabled:bool=False
    legal_hold_override:bool=True
    status:str=Field(default="DRAFT",pattern="^(DRAFT|ACTIVE|RETIRED)$")

class LegalHoldIn(BaseModel):
    hold_reference:str
    scope:str
    reason:str

@router.post("/requests")
def create_request(body:PrivacyRequestIn,db:Session=Depends(get_db)):
    row=PrivacyRequest(**body.model_dump())
    db.add(row);db.commit();db.refresh(row)
    return {"request_id":row.id,"status":row.status}

@router.patch("/requests/{request_id}/verification")
def verify_request(request_id:int,body:VerifyIn,db:Session=Depends(get_db),user=Depends(current_user)):
    row=db.get(PrivacyRequest,request_id)
    if not row: raise HTTPException(404,"Privacy request not found")
    row.identity_verification_state=body.state
    row.assigned_to=user.email
    db.commit()
    return {"request_id":row.id,"identity_verification_state":row.identity_verification_state}

@router.post("/requests/{request_id}/complete")
def complete(request_id:int,body:CompleteIn,db:Session=Depends(get_db),user=Depends(current_user)):
    row=db.get(PrivacyRequest,request_id)
    if not row: raise HTTPException(404,"Privacy request not found")
    try: complete_privacy_request(db,row,body.response_reference)
    except ValueError as e: raise HTTPException(409,str(e))
    return {"request_id":row.id,"status":row.status}

@router.post("/retention-rules")
def create_retention_rule(body:RetentionRuleIn,db:Session=Depends(get_db),user=Depends(current_user)):
    if user.role!="admin": raise HTTPException(403,"Admin required")
    row=RetentionRule(owner_email=user.email,**body.model_dump())
    db.add(row);db.commit();db.refresh(row)
    return {"rule_id":row.id,"record_class":row.record_class,"status":row.status}

@router.get("/retention-check/{record_class}")
def retention_check(record_class:str,db:Session=Depends(get_db),user=Depends(current_user)):
    return can_delete_record(db,record_class)

@router.post("/legal-holds")
def create_hold(body:LegalHoldIn,db:Session=Depends(get_db),user=Depends(current_user)):
    if user.role!="admin": raise HTTPException(403,"Admin required")
    row=LegalHold(owner_email=user.email,**body.model_dump())
    db.add(row);db.commit();db.refresh(row)
    return {"hold_id":row.id,"status":row.status}
