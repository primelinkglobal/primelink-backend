from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from app.api.deps import current_user
from app.db.session import get_db
from app.models.entities import User
from app.core.security import hash_password
from app.services.auth_service import issue_db_token, consume_token
from app.services.mailer import send_email
from app.core.config import settings

router = APIRouter(prefix="/api/v1/users", tags=["users"])

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=12, max_length=200)
    role: str = "operator"

class VerifyIn(BaseModel):
    token: str

@router.post("")
def create_user(body: UserCreate, db: Session=Depends(get_db), actor=Depends(current_user)):
    if actor.role != "admin":
        raise HTTPException(403, "Admin required")
    if db.query(User).filter(User.email==body.email).first():
        raise HTTPException(409, "User already exists")
    u=User(email=body.email,password_hash=hash_password(body.password),role=body.role,active=True)
    db.add(u); db.commit(); db.refresh(u)
    raw=issue_db_token(db,u,"VERIFY",timedelta(hours=settings.email_verification_hours))
    send_email(u.email,"Verify PrimeLink account",f"Verification token: {raw}")
    return {"id":u.id,"email":u.email,"role":u.role,"verification_token_issued":True}

@router.post("/verify")
def verify(body: VerifyIn, db: Session=Depends(get_db)):
    rec=consume_token(db,body.token,"VERIFY")
    if not rec:
        raise HTTPException(400,"Invalid or expired verification token")
    return {"status":"verified","user_id":rec.user_id}
