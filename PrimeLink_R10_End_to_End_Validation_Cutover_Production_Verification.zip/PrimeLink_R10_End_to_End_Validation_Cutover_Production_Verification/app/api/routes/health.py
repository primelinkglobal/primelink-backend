from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.config import settings

router = APIRouter(prefix="/health", tags=["health"])

@router.get("/live")
def live():
    return {"status":"ok","service":settings.app_name,"version":settings.app_version}

@router.get("/ready")
def ready(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {
        "status":"ready",
        "database":"reachable",
        "ai_matching_enabled":settings.ai_matching_enabled,
        "external_discovery_enabled":settings.external_discovery_enabled,
        "automatic_introductions_enabled":settings.automatic_introductions_enabled
    }
