import time
from starlette.middleware.base import BaseHTTPMiddleware
from app.observability.metrics import REQUESTS,LATENCY

class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        start=time.perf_counter()
        response=await call_next(request)
        path=request.url.path
        REQUESTS.labels(request.method,path,str(response.status_code)).inc()
        LATENCY.labels(request.method,path).observe(time.perf_counter()-start)
        return response
