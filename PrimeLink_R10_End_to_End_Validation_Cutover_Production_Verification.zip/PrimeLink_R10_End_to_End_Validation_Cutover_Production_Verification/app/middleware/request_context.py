import uuid, time
from starlette.middleware.base import BaseHTTPMiddleware
from app.observability.logging import logger

class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        request_id=request.headers.get("x-request-id") or str(uuid.uuid4())
        start=time.perf_counter()
        try:
            response=await call_next(request)
            status=response.status_code
            return response
        finally:
            duration_ms=round((time.perf_counter()-start)*1000,2)
            logger.info("http_request",request_id=request_id,method=request.method,
                        path=request.url.path,status=locals().get("status",500),duration_ms=duration_ms)
