from datetime import datetime
from pydantic import BaseModel, Field

class OpportunityTransitionIn(BaseModel):
    to_state: str
    note: str | None = None

class CRMActivityIn(BaseModel):
    participant_id: int
    activity_type: str
    channel: str | None = None
    subject: str | None = None
    note: str | None = None
    next_action_at: datetime | None = None

class TaskIn(BaseModel):
    task_type: str
    title: str
    description: str | None = None
    owner_email: str
    entity_type: str | None = None
    entity_id: str | None = None
    priority: str = "NORMAL"
    due_at: datetime | None = None

class TaskStatusIn(BaseModel):
    status: str = Field(pattern="^(OPEN|IN_PROGRESS|DONE|CANCELLED)$")

class ReviewDecisionIn(BaseModel):
    entity_type: str
    entity_id: str
    review_type: str
    decision: str
    reason: str | None = None

class IntroductionPreparationIn(BaseModel):
    match_id: int
    relationship_owner_email: str

class IntroductionGateUpdate(BaseModel):
    human_review_complete: bool | None = None
    verification_complete: bool | None = None
    compliance_gate_passed: bool | None = None
    counterparty_consent_complete: bool | None = None
