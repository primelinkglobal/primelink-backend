def score_match(mandate, opportunity):
    score = 0.0
    reasons = []
    if mandate.geography.lower() == opportunity.geography.lower():
        score += 0.35; reasons.append("geography alignment")
    if mandate.sector.lower() == opportunity.sector.lower():
        score += 0.35; reasons.append("sector alignment")
    if opportunity.value is not None:
        low_ok = mandate.ticket_min is None or opportunity.value >= mandate.ticket_min
        high_ok = mandate.ticket_max is None or opportunity.value <= mandate.ticket_max
        if low_ok and high_ok:
            score += 0.20; reasons.append("value/ticket alignment")
    if opportunity.verification_state not in {"DISCOVERED_UNVERIFIED","REJECTED"}:
        score += 0.10; reasons.append("advanced verification state")
    return round(min(score,1.0), 3), ", ".join(reasons) or "limited structured alignment"

def match_is_not_verification():
    return True
