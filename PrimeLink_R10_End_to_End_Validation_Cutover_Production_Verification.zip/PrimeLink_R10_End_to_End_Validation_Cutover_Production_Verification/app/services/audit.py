from app.models.entities import AuditEvent
def record(db, actor, action, entity_type, entity_id, details=None):
    event = AuditEvent(actor=actor, action=action, entity_type=entity_type,
                       entity_id=str(entity_id), details=details)
    db.add(event)
    db.commit()
    return event
