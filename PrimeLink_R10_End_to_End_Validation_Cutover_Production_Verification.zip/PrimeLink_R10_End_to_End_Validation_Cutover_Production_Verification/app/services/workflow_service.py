import json
from datetime import datetime
from app.models.entities import WorkflowEvent, Task, NotificationOutbox

def enqueue_event(db, event_type, entity_type, entity_id, payload=None):
    ev=WorkflowEvent(
        event_type=event_type,
        entity_type=entity_type,
        entity_id=str(entity_id),
        payload_json=json.dumps(payload or {}),
        status="PENDING"
    )
    db.add(ev); db.commit(); db.refresh(ev)
    return ev

def process_event(db, event):
    payload=json.loads(event.payload_json or "{}")
    if event.event_type == "CREATE_REVIEW_TASK":
        db.add(Task(
            task_type="OPPORTUNITY_REVIEW",
            title=f"Review opportunity #{event.entity_id}",
            owner_email=payload.get("owner_email","admin@example.com"),
            entity_type="opportunity",
            entity_id=str(event.entity_id),
            priority="HIGH"
        ))
    elif event.event_type == "NOTIFY_OPPORTUNITY_OWNER_INFORMATION_REQUIRED":
        recipient=payload.get("owner_email")
        if recipient:
            db.add(NotificationOutbox(
                recipient=recipient,
                channel="EMAIL",
                template_key="opportunity_information_required",
                subject="PrimeLink opportunity requires more information",
                body=f"Opportunity #{event.entity_id} requires additional information."
            ))
    elif event.event_type == "QUEUE_MATCHING_REVIEW":
        db.add(Task(
            task_type="MATCHING_REVIEW",
            title=f"Review matching readiness for opportunity #{event.entity_id}",
            owner_email=payload.get("owner_email","admin@example.com"),
            entity_type="opportunity",
            entity_id=str(event.entity_id)
        ))
    elif event.event_type == "CREATE_INTRODUCTION_PREP_TASK":
        db.add(Task(
            task_type="INTRODUCTION_PREPARATION",
            title=f"Prepare controlled introduction for opportunity #{event.entity_id}",
            owner_email=payload.get("owner_email","admin@example.com"),
            entity_type="opportunity",
            entity_id=str(event.entity_id),
            priority="HIGH"
        ))
    event.status="PROCESSED"
    event.processed_at=datetime.utcnow()
    event.attempts += 1
    db.commit()
