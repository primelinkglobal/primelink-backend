from datetime import datetime
from app.services.mailer import send_email

def process_notification(db, row):
    try:
        if row.channel == "EMAIL":
            send_email(row.recipient, row.subject or "PrimeLink notification", row.body)
        else:
            raise RuntimeError(f"Unsupported notification channel: {row.channel}")
        row.status="SENT"
        row.sent_at=datetime.utcnow()
        row.attempts += 1
        row.last_error=None
    except Exception as e:
        row.status="FAILED"
        row.attempts += 1
        row.last_error=str(e)
    db.commit()
