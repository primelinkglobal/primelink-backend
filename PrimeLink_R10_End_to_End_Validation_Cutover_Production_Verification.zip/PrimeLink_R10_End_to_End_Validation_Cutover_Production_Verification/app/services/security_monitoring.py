import json, hashlib
from datetime import datetime, timedelta
from app.models.entities import (
    SecurityEvent, WorkerHeartbeat, BackupStatus, AuditIntegrityCheckpoint,
    AuditEvent, CommercialAuditEvent, AIAuditEvent, DiscoveryAuditEvent
)

def record_security_event(db,event_type,severity,actor_or_subject=None,source_ip=None,details=None):
    row=SecurityEvent(event_type=event_type,severity=severity,
        actor_or_subject=actor_or_subject,source_ip=source_ip,
        details_json=json.dumps(details or {}))
    db.add(row);db.commit();db.refresh(row)
    return row

def update_worker_heartbeat(db,name,status="HEALTHY",details=None):
    row=db.query(WorkerHeartbeat).filter(WorkerHeartbeat.worker_name==name).first()
    if not row:
        row=WorkerHeartbeat(worker_name=name)
        db.add(row)
    row.status=status;row.last_seen_at=datetime.utcnow();row.details=details
    db.commit()
    return row

def audit_integrity_checkpoint(db):
    parts=[]
    count=0
    for model in [AuditEvent,CommercialAuditEvent,AIAuditEvent,DiscoveryAuditEvent]:
        rows=db.query(model).order_by(model.id).all()
        for r in rows:
            parts.append(f"{model.__tablename__}:{r.id}:{r.created_at}")
            count += 1
    digest=hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()
    row=AuditIntegrityCheckpoint(checkpoint_scope="core_audit_tables",record_count=count,digest=digest)
    db.add(row);db.commit();db.refresh(row)
    return row

def backup_freshness(db,hours):
    row=db.query(BackupStatus).order_by(BackupStatus.completed_at.desc()).first()
    if not row:
        return {"fresh":False,"reason":"no_backup_status"}
    return {"fresh":row.completed_at >= datetime.utcnow()-timedelta(hours=hours),
            "completed_at":row.completed_at,"verified_restore":row.verified_restore}
