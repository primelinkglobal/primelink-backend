from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.security import generate_opaque_token, token_hash
from app.models.entities import AuthToken, User

def issue_db_token(db: Session, user: User, token_type: str, lifetime: timedelta) -> str:
    raw = generate_opaque_token()
    rec = AuthToken(
        user_id=user.id,
        token_hash=token_hash(raw),
        token_type=token_type,
        expires_at=datetime.utcnow() + lifetime,
    )
    db.add(rec)
    db.commit()
    return raw

def consume_token(db: Session, raw: str, token_type: str):
    rec = db.query(AuthToken).filter(
        AuthToken.token_hash == token_hash(raw),
        AuthToken.token_type == token_type,
        AuthToken.revoked == False,
        AuthToken.used_at.is_(None),
    ).first()
    if not rec or rec.expires_at < datetime.utcnow():
        return None
    rec.used_at = datetime.utcnow()
    db.commit()
    return rec

def revoke_user_tokens(db: Session, user_id: int, token_type: str | None = None):
    q = db.query(AuthToken).filter(AuthToken.user_id == user_id, AuthToken.revoked == False)
    if token_type:
        q = q.filter(AuthToken.token_type == token_type)
    for rec in q.all():
        rec.revoked = True
    db.commit()
