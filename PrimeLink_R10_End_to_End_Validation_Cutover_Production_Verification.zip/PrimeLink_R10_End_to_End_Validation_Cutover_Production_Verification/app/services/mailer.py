from app.core.config import settings

def send_email(to: str, subject: str, body: str):
    if settings.mail_mode == "console":
        print(f"[MAIL to={to}] {subject}\n{body}")
        return {"mode":"console","sent":True}
    raise RuntimeError("Production mail provider not configured. D3/D7 must wire the approved provider.")
