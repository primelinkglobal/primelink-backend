import json
from datetime import datetime
from app.models.entities import OnboardingApplication, Participant

ACTIVATABLE_DECISIONS={"APPROVE","APPROVE_WITH_RESTRICTIONS"}

def review_application(db, application, reviewer_email, decision, reason=None):
    if decision not in {"APPROVE","APPROVE_WITH_RESTRICTIONS","HOLD","REJECT"}:
        raise ValueError("Unsupported onboarding decision")
    if decision in ACTIVATABLE_DECISIONS:
        if not application.terms_accepted:
            raise ValueError("Terms must be accepted before activation.")
        if application.verification_required and application.verification_state != "VERIFIED":
            raise ValueError("Required verification is incomplete.")
        if not application.participant_id:
            profile=json.loads(application.profile_json or "{}")
            participant=Participant(
                participant_type=application.participant_type,
                name=application.applicant_name,
                organization=application.organization,
                geography=application.geography,
                verification_state=application.verification_state,
                status="ACTIVE" if decision=="APPROVE" else "RESTRICTED"
            )
            db.add(participant); db.commit(); db.refresh(participant)
            application.participant_id=participant.id
    application.review_state=decision
    application.reviewer_email=reviewer_email
    application.review_reason=reason
    application.reviewed_at=datetime.utcnow()
    db.commit()
    return application
