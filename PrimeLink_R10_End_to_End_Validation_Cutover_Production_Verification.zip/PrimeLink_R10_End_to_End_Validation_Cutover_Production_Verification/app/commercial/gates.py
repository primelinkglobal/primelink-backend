from datetime import datetime

def agreement_is_active(a):
    if a.status != "ACTIVE":
        return False
    now=datetime.utcnow()
    if a.effective_date and a.effective_date > now:
        return False
    if a.expiry_date and a.expiry_date < now:
        return False
    return True

def introduction_gate(prep, agreement, prior_check_complete: bool):
    failures=[]
    if prep.status != "READY_FOR_AUTHORIZED_INTRODUCTION":
        failures.append("preparation_not_ready")
    if not prep.human_review_complete: failures.append("human_review")
    if not prep.verification_complete: failures.append("verification")
    if not prep.compliance_gate_passed: failures.append("compliance")
    if not prep.counterparty_consent_complete: failures.append("consent")
    if agreement is None or not agreement_is_active(agreement):
        failures.append("active_agreement")
    if not prior_check_complete:
        failures.append("prior_relationship_check")
    return {"allowed":not failures,"failures":failures}

def fee_event_gate(fee_event, agreement):
    failures=[]
    if agreement is None or not agreement_is_active(agreement):
        failures.append("active_agreement")
    if not fee_event.trigger_type: failures.append("trigger_type")
    if not fee_event.event_evidence: failures.append("event_evidence")
    if not fee_event.calculation_basis: failures.append("calculation_basis")
    if fee_event.duplicate_claim: failures.append("duplicate_claim")
    if fee_event.approval_state != "APPROVED": failures.append("commercial_approval")
    return {"validated":not failures,"failures":failures}

def invoice_gate(fee_event):
    return fee_event.status == "VALIDATED" and fee_event.amount is not None and fee_event.currency is not None
