def invoice_balance(invoice):
    return round(float(invoice.amount or 0)-float(invoice.paid_amount or 0),2)

def reconcile(invoice, collections):
    received=round(sum(float(c.amount or 0) for c in collections if c.status=="RECEIVED"),2)
    expected=round(float(invoice.amount or 0),2)
    return {
        "expected":expected,
        "received":received,
        "variance":round(received-expected,2),
        "reconciled":received==expected
    }
