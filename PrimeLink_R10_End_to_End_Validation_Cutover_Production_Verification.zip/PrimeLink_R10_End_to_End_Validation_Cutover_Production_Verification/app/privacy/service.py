from datetime import datetime
from app.models.entities import PrivacyRequest, LegalHold, RetentionRule

def can_delete_record(db, record_class: str):
    active_hold=db.query(LegalHold).filter(LegalHold.status=="ACTIVE").first()
    if active_hold:
        return {"allowed":False,"reason":"active_legal_hold"}
    rule=db.query(RetentionRule).filter(RetentionRule.record_class==record_class,
                                        RetentionRule.status=="ACTIVE").first()
    if not rule:
        return {"allowed":False,"reason":"no_active_retention_rule"}
    if not rule.deletion_enabled:
        return {"allowed":False,"reason":"deletion_disabled"}
    return {"allowed":True,"reason":"eligible_subject_to_record_age_and_scope"}

def complete_privacy_request(db, request, response_reference):
    if request.identity_verification_state!="VERIFIED":
        raise ValueError("Identity/authority verification incomplete.")
    request.status="COMPLETED"
    request.response_reference=response_reference
    request.completed_at=datetime.utcnow()
    db.commit()
    return request
