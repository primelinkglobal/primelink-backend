from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.security.rate_limit import limiter
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.middleware.request_context import RequestContextMiddleware
from app.middleware.metrics import MetricsMiddleware
from app.observability.logging import configure_logging
from app.core.config import settings
from app.db.base import Base
from app.db.session import engine
from app.models import entities  # noqa
from app.api.routes import auth, health, core, users, workflows, intelligence, discovery, commercial, privacy, monitoring

configure_logging()

if settings.app_env != "production":
    Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.app_name, version=settings.app_version)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_host_list)
if settings.security_headers_enabled:
    app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestContextMiddleware)
if settings.metrics_enabled:
    app.add_middleware(MetricsMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(health.router)
app.include_router(core.router)
app.include_router(users.router)
app.include_router(workflows.router)
app.include_router(intelligence.router)
app.include_router(discovery.router)
app.include_router(commercial.router)
app.include_router(privacy.router)
app.include_router(monitoring.router)

@app.get("/", include_in_schema=False)
def index():
    return FileResponse(Path(__file__).parent/"static"/"index.html")


@app.get("/runtime", include_in_schema=False)
def runtime():
    return {
        "application": settings.app_name,
        "version": settings.app_version,
        "environment": settings.app_env,
        "state": "UNIFIED_APPLICATION_BASELINE_READY",
        "database_configured": bool(settings.database_url and not settings.database_url.startswith("sqlite")),
        "automatic_introductions_enabled": settings.automatic_introductions_enabled,
        "external_discovery_enabled": settings.external_discovery_enabled,
    }


@app.get("/business-core", include_in_schema=False)
def business_core():
    return {
        "stage": "R4",
        "state": "R4_BUSINESS_CORE_READY",
        "domains": [
            "participants",
            "investor_mandates",
            "partners",
            "opportunities",
            "crm",
            "relationships",
            "workflow_events"
        ],
        "automatic_introductions": False
    }


@app.get("/intelligence", include_in_schema=False)
def intelligence():
    return {
        "stage": "R5",
        "state": "R5_AI_MATCHING_INTELLIGENCE_READY",
        "matching_mode": "candidate_generation_with_human_review",
        "automatic_introductions": False,
        "explainability_required": True,
        "provenance_required": True
    }


@app.get("/discovery-runtime", include_in_schema=False)
def discovery_runtime():
    return {
        "stage": "R6",
        "state": "R6_EXTERNAL_DISCOVERY_CONNECTOR_RUNTIME_READY",
        "external_discovery_enabled": settings.external_discovery_enabled,
        "default_behavior": "disabled_until_approved",
        "provenance_required": True,
        "auto_verify": False
    }


@app.get("/commercial-runtime", include_in_schema=False)
def commercial_runtime():
    return {
        "stage": "R7",
        "state": "R7_COMMERCIAL_REVENUE_WORKFLOWS_READY",
        "money_precision": "decimal",
        "protected_introduction_required": True,
        "projected_revenue_is_collected_cash": False,
        "reconciliation_required": True
    }


@app.get("/control-plane", include_in_schema=False)
def control_plane():
    return {
        "stage": "R8",
        "state": "R8_CONTROL_PLANE_READY",
        "privacy_identity_verification_required": True,
        "legal_hold_blocks_disposal": True,
        "restore_test_required_for_recovery_assurance": True,
        "critical_alerts_require_owner": True
    }


@app.get("/deployment-state", include_in_schema=False)
def deployment_state():
    return {
        "stage": "R9",
        "state": "R9_AUTOMATED_DEPLOYMENT_READY",
        "deployment_mode": "automated",
        "migration_gate_required": True,
        "post_deploy_verification_required": True,
        "rollback_readiness_required": True
    }


@app.get("/production-verification-state", include_in_schema=False)
def production_verification_state():
    return {
        "stage": "R10",
        "state": "R10_VALIDATION_CUTOVER_FRAMEWORK_READY",
        "production_verified": False,
        "target_state": "PRIMELINK_REBUILD_PRODUCTION_VERIFIED",
        "cutover_requires_explicit_gate": True
    }
