import re
from app.ai.providers.base import IntelligenceProvider
def toks(s): return set(re.findall(r"[a-z0-9]+",s.lower()))
class LocalBaselineProvider(IntelligenceProvider):
    def semantic_similarity(self, mandate_text, opportunity_text):
        a,b=toks(mandate_text),toks(opportunity_text)
        return round(len(a&b)/max(1,len(a|b)),4)
    def explain(self, mandate_text, opportunity_text, evidence):
        aligned=", ".join(evidence.get("aligned",[])) or "limited structured alignment"
        return f"Candidate prioritized from structured and semantic alignment: {aligned}. Human review required."
