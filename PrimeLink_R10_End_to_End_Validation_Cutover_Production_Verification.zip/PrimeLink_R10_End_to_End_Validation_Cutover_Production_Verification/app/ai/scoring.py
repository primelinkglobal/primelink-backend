def structured_score(m,o):
    score=0.0; aligned=[]
    if m.geography.lower()==o.geography.lower(): score+=0.35; aligned.append("geography")
    if m.sector.lower()==o.sector.lower(): score+=0.35; aligned.append("sector")
    if o.value is not None:
        lo=m.ticket_min is None or o.value>=m.ticket_min
        hi=m.ticket_max is None or o.value<=m.ticket_max
        if lo and hi: score+=0.20; aligned.append("ticket/value")
    if o.verification_state not in {"DISCOVERED_UNVERIFIED","REJECTED"}:
        score+=0.10; aligned.append("verification-state signal")
    return round(min(score,1.0),4), aligned
def combine(structured,semantic):
    return round(0.75*structured+0.25*semantic,4)
