from sqlalchemy.orm import Session
from app.models.entities import Opportunity
def retrieve_candidates(db:Session, mandate, limit:int=100):
    q=db.query(Opportunity).filter(Opportunity.stage.notin_(["REJECTED","ARCHIVED"]))
    # High-recall retrieval: geography OR sector filtering happens in scoring rather than excluding all mismatches.
    return q.order_by(Opportunity.created_at.desc()).limit(limit).all()
