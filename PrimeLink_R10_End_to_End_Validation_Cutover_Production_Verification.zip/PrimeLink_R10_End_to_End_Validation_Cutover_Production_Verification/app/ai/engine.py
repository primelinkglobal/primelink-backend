import json
from app.core.config import settings
from app.models.entities import AIMatchRun,AIMatchCandidate,AIAuditEvent
from app.ai.retrieval import retrieve_candidates
from app.ai.scoring import structured_score,combine
from app.ai.providers.local_baseline import LocalBaselineProvider

MODEL_VERSION="d4-local-baseline-v1"
PROMPT_VERSION="d4-explain-v1"

def mandate_text(m):
    return " ".join(filter(None,[m.objective,m.geography,m.sector,m.constraints or ""]))
def opportunity_text(o):
    return " ".join(filter(None,[o.title,o.opportunity_type,o.geography,o.sector,o.provenance or ""]))

def run_intelligence(db, mandate, actor, limit=50):
    if not settings.ai_matching_enabled:
        raise RuntimeError("AI matching kill switch is OFF")
    provider=LocalBaselineProvider()
    candidates=retrieve_candidates(db,mandate,limit)
    run=AIMatchRun(mandate_id=mandate.id,model_version=MODEL_VERSION,candidate_count=len(candidates))
    db.add(run); db.commit(); db.refresh(run)
    rows=[]
    for o in candidates:
        ss,aligned=structured_score(mandate,o)
        sem=provider.semantic_similarity(mandate_text(mandate),opportunity_text(o))
        final=combine(ss,sem)
        evidence={"aligned":aligned,"opportunity_verification_state":o.verification_state,
                  "source":o.source,"provenance":o.provenance}
        explanation=provider.explain(mandate_text(mandate),opportunity_text(o),evidence)
        row=AIMatchCandidate(run_id=run.id,opportunity_id=o.id,structured_score=ss,
            semantic_score=sem,final_score=final,explanation=explanation,
            evidence_json=json.dumps(evidence),human_review_state="PENDING")
        db.add(row); rows.append(row)
    db.add(AIAuditEvent(actor=actor,action="AI_MATCH_RUN",model_version=MODEL_VERSION,
        entity_type="mandate",entity_id=str(mandate.id),
        details_json=json.dumps({"candidate_count":len(candidates),"prompt_version":PROMPT_VERSION})))
    db.commit()
    return run,sorted(rows,key=lambda x:x.final_score,reverse=True)
