def events_for_opportunity_transition(from_state: str, to_state: str):
    events=[]
    if to_state == "UNDER_REVIEW":
        events.append("CREATE_REVIEW_TASK")
    if to_state == "NEEDS_INFORMATION":
        events.append("NOTIFY_OPPORTUNITY_OWNER_INFORMATION_REQUIRED")
    if to_state == "VERIFIED":
        events.append("QUEUE_MATCHING_REVIEW")
    if to_state == "SHORTLISTED":
        events.append("CREATE_INTRODUCTION_PREP_TASK")
    return events
