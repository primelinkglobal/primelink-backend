ALLOWED = {
    "SUBMITTED": {"UNDER_REVIEW", "REJECTED"},
    "UNDER_REVIEW": {"NEEDS_INFORMATION", "VERIFIED", "REJECTED"},
    "NEEDS_INFORMATION": {"UNDER_REVIEW", "REJECTED"},
    "VERIFIED": {"MATCHING", "ARCHIVED"},
    "MATCHING": {"SHORTLISTED", "ARCHIVED"},
    "SHORTLISTED": {"INTRODUCTION_PREP", "ARCHIVED"},
    "INTRODUCTION_PREP": {"INTRODUCED", "ARCHIVED"},
    "INTRODUCED": {"IN_PROGRESS", "CLOSED"},
    "IN_PROGRESS": {"CLOSED", "ARCHIVED"},
    "CLOSED": set(),
    "REJECTED": set(),
    "ARCHIVED": set(),
}

def can_transition(from_state: str, to_state: str) -> bool:
    return to_state in ALLOWED.get(from_state, set())
