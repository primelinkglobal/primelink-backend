from app.connectors.providers.local_curated_feed import LocalCuratedFeedConnector

CONNECTOR_FACTORIES = {
    "local_curated_feed": lambda: LocalCuratedFeedConnector(),
}

def get_connector(source_key: str):
    factory = CONNECTOR_FACTORIES.get(source_key)
    if not factory:
        raise KeyError(f"No connector implementation registered for {source_key}")
    return factory()
