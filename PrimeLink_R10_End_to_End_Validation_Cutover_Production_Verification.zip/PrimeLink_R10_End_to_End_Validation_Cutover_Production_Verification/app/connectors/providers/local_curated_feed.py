import json
from datetime import datetime
from pathlib import Path
from app.connectors.base import ExternalConnector, ConnectorResult

class LocalCuratedFeedConnector(ExternalConnector):
    source_key = "local_curated_feed"

    def __init__(self, path: str = "data/discovery/curated_feed.json"):
        self.path = Path(path)

    def health(self):
        ok = self.path.exists()
        return {
            "reachable": ok,
            "provenance_working": ok,
            "scope_enforced": True,
            "details": "Local curated feed available" if ok else "Feed file missing"
        }

    def search(self, query: dict, limit: int = 25):
        if not self.path.exists():
            return []
        items = json.loads(self.path.read_text(encoding="utf-8"))
        geography = (query.get("geography") or "").lower()
        sector = (query.get("sector") or "").lower()
        results=[]
        for item in items:
            geo_ok = not geography or geography in (item.get("geography") or "").lower()
            sec_ok = not sector or sector in (item.get("sector") or "").lower()
            if not (geo_ok or sec_ok):
                continue
            results.append(ConnectorResult(
                source_object_id=str(item.get("id")) if item.get("id") is not None else None,
                canonical_url=item.get("url"),
                title=item["title"],
                opportunity_type=item.get("opportunity_type"),
                geography=item.get("geography"),
                sector=item.get("sector"),
                value=item.get("value"),
                summary=item.get("summary"),
                provenance={
                    "source_key": self.source_key,
                    "source_reference": item.get("url") or f"local-feed:{item.get('id')}",
                    "retrieval_method": "curated_feed",
                    "source_record": item.get("source_record") or item.get("id")
                },
                retrieved_at=datetime.utcnow()
            ))
            if len(results) >= limit:
                break
        return results
