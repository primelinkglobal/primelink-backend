from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime

@dataclass
class ConnectorResult:
    source_object_id: str | None
    canonical_url: str | None
    title: str
    opportunity_type: str | None
    geography: str | None
    sector: str | None
    value: float | None
    summary: str | None
    provenance: dict
    retrieved_at: datetime

class ExternalConnector(ABC):
    source_key: str

    @abstractmethod
    def health(self) -> dict: ...

    @abstractmethod
    def search(self, query: dict, limit: int = 25) -> list[ConnectorResult]: ...
