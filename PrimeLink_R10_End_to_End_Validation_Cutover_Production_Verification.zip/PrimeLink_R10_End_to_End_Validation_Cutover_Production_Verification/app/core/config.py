from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "PrimeLink Global"
    app_env: str = "development"
    app_version: str = "R1"

    database_url: str = "sqlite:///./data/primelink.db"
    db_pool_size: int = 5
    db_max_overflow: int = 10

    jwt_secret: str = "CHANGE_ME"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 30
    refresh_token_days: int = 7
    password_reset_minutes: int = 30
    email_verification_hours: int = 24

    bootstrap_admin_email: str = "admin@example.com"
    bootstrap_admin_password: str = "CHANGE_ME_NOW"
    allow_bootstrap_admin: bool = False

    public_base_url: str = "https://primelinkcapital.com"
    cors_origins: str = "https://primelinkcapital.com,https://www.primelinkcapital.com"

    external_discovery_enabled: bool = False
    discovery_max_results_per_source: int = 25
    discovery_request_timeout_seconds: int = 15
    discovery_store_raw_payloads: bool = False
    discovery_default_verification_state: str = "DISCOVERED_UNVERIFIED"
    discovery_allow_public_web: bool = False
    ai_matching_enabled: bool = True
    automatic_introductions_enabled: bool = False

    mail_mode: str = "console"
    mail_from: str = "no-reply@example.com"

    trust_proxy_headers: bool = False
    secure_cookies: bool = False
    security_headers_enabled: bool = True
    rate_limit_enabled: bool = True
    login_rate_limit: str = "5/minute"
    api_default_rate_limit: str = "120/minute"
    trusted_hosts: str = "localhost,127.0.0.1,*.onrender.com,primelinkcapital.com,www.primelinkcapital.com"
    metrics_enabled: bool = True
    structured_logging_enabled: bool = True
    privacy_retention_enforcement_enabled: bool = True
    audit_log_tamper_check_enabled: bool = True
    require_mfa_for_admin: bool = False
    backup_freshness_hours: int = 24
    worker_health_stale_seconds: int = 120

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def trusted_host_list(self):
        return [x.strip() for x in self.trusted_hosts.split(",") if x.strip()]

    @property
    def cors_origin_list(self):
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

@lru_cache
def get_settings():
    return Settings()

settings = get_settings()
