import json
from pathlib import Path
from typing import Dict, Type
from app.core.connectors import BaseConnector, StaticExampleConnector, ConnectorError

class ConnectorRegistry:
    def __init__(self, registry_path="config/r6/connector_registry.json"):
        self.policy=json.loads(Path(registry_path).read_text())
        self._implementations: Dict[str, Type[BaseConnector]]={"static_example": StaticExampleConnector}

    def is_approved(self, connector_id: str) -> bool:
        for c in self.policy.get("connectors",[]):
            if c.get("connector_id")==connector_id:
                return bool(c.get("approval_required") is False or c.get("approved") is True)
        return connector_id=="static_example"

    def run(self, connector_id: str, query: dict):
        if connector_id!="static_example" and not self.is_approved(connector_id):
            raise ConnectorError("connector is not approved")
        impl=self._implementations.get(connector_id)
        if not impl:
            raise ConnectorError("connector implementation unavailable")
        return impl().discover(query)
