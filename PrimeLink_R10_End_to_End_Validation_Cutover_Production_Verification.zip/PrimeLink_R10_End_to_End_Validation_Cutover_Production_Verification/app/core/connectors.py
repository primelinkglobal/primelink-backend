from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional
import uuid

@dataclass
class DiscoveryRecord:
    record_id: str
    connector_id: str
    source_name: str
    source_reference: str
    retrieved_at: str
    retrieval_method: str
    raw_payload: Dict[str, Any]
    normalized_payload: Dict[str, Any]
    verification_state: str = "discovered_unverified"
    attribution: Optional[str] = None
    connector_version: str = "R6-1"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

class ConnectorError(RuntimeError):
    pass

class BaseConnector:
    connector_id = "base"
    version = "R6-1"

    def fetch(self, query: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
        raise NotImplementedError

    def normalize(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        return dict(raw)

    def discover(self, query: Dict[str, Any]) -> List[DiscoveryRecord]:
        results=[]
        try:
            rows=self.fetch(query)
        except Exception as exc:
            raise ConnectorError(f"{self.connector_id} unavailable") from exc
        for raw in rows:
            normalized=self.normalize(raw)
            src_ref=str(raw.get("source_reference") or raw.get("url") or raw.get("id") or "")
            if not src_ref:
                # fail closed: a source without a stable reference is not accepted
                continue
            results.append(DiscoveryRecord(
                record_id=str(uuid.uuid4()),
                connector_id=self.connector_id,
                source_name=str(raw.get("source_name") or self.connector_id),
                source_reference=src_ref,
                retrieved_at=datetime.now(timezone.utc).isoformat(),
                retrieval_method="connector",
                raw_payload=raw,
                normalized_payload=normalized,
                verification_state="discovered_unverified",
                attribution=str(raw.get("attribution") or raw.get("source_name") or self.connector_id),
                connector_version=self.version
            ))
        return results

class StaticExampleConnector(BaseConnector):
    """Non-production connector used only to verify the R6 contract."""
    connector_id="static_example"
    def fetch(self, query: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
        return [{
            "source_name":"example-source",
            "source_reference":"example://record/1",
            "attribution":"Example Source",
            "title":"Synthetic R6 verification record",
            "geography":query.get("geography"),
            "sector_or_asset_type":query.get("sector_or_asset_type"),
        }]
