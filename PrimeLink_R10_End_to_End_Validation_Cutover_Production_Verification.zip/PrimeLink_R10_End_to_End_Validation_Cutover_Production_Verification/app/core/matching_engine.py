from dataclasses import dataclass, asdict
from typing import Any, Dict, List

WEIGHTS = {
    "geography_fit": 0.20,
    "sector_asset_fit": 0.20,
    "ticket_capacity_fit": 0.15,
    "liquidity_horizon_fit": 0.10,
    "risk_fit": 0.10,
    "transaction_structure_fit": 0.10,
    "relationship_context": 0.05,
    "verification_quality": 0.10,
}

@dataclass
class MatchResult:
    overall_score: float
    dimension_scores: Dict[str, float]
    positive_factors: List[str]
    negative_factors: List[str]
    missing_information: List[str]
    verification_state: str
    review_requirement: str
    engine_version: str = "R5-rules-1"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

def _norm(value):
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip().lower()
    return value

def _contains_fit(left, right):
    if not left or not right:
        return None
    if isinstance(left, (list, tuple, set)):
        left = {_norm(x) for x in left}
    else:
        left = {_norm(left)}
    if isinstance(right, (list, tuple, set)):
        right = {_norm(x) for x in right}
    else:
        right = {_norm(right)}
    return 100.0 if left.intersection(right) else 0.0

def _range_fit(target_min, target_max, value):
    if value in (None, ""):
        return None
    try:
        v = float(value)
        lo = float(target_min) if target_min not in (None, "") else None
        hi = float(target_max) if target_max not in (None, "") else None
    except Exception:
        return None
    if lo is not None and v < lo:
        return 0.0
    if hi is not None and v > hi:
        return 0.0
    return 100.0

def score_match(mandate: Dict[str, Any], opportunity: Dict[str, Any], relationship_context: float = 0.0) -> MatchResult:
    scores, pos, neg, missing = {}, [], [], []

    geo = _contains_fit(mandate.get("geography"), opportunity.get("geography"))
    if geo is None: missing.append("geography")
    else:
        scores["geography_fit"] = geo
        (pos if geo else neg).append("geography aligned" if geo else "geography mismatch")

    sec = _contains_fit(mandate.get("sector_or_asset_type"), opportunity.get("sector_or_asset_type"))
    if sec is None: missing.append("sector_or_asset_type")
    else:
        scores["sector_asset_fit"] = sec
        (pos if sec else neg).append("sector/asset aligned" if sec else "sector/asset mismatch")

    ticket = _range_fit(mandate.get("ticket_min"), mandate.get("ticket_max"), opportunity.get("value_or_size"))
    if ticket is None: missing.append("ticket_or_value")
    else:
        scores["ticket_capacity_fit"] = ticket
        (pos if ticket else neg).append("ticket/capacity aligned" if ticket else "ticket/capacity mismatch")

    for key, mkey, okey, label in [
        ("liquidity_horizon_fit","liquidity_horizon","liquidity_horizon","liquidity horizon"),
        ("risk_fit","risk_profile","risk_profile","risk profile"),
        ("transaction_structure_fit","transaction_type","transaction_type","transaction structure"),
    ]:
        s = _contains_fit(mandate.get(mkey), opportunity.get(okey))
        if s is None: missing.append(label)
        else:
            scores[key]=s
            (pos if s else neg).append(f"{label} aligned" if s else f"{label} mismatch")

    scores["relationship_context"] = max(0.0, min(100.0, float(relationship_context or 0.0)))

    mver = _norm(mandate.get("verification_state"))
    over = _norm(opportunity.get("verification_state"))
    if mver == "verified" and over == "verified":
        scores["verification_quality"] = 100.0
        pos.append("both records verified")
        verification_state = "verified_inputs"
    elif mver or over:
        scores["verification_quality"] = 50.0
        neg.append("one or more records not fully verified")
        verification_state = "mixed_verification"
    else:
        scores["verification_quality"] = 0.0
        missing.append("verification_state")
        verification_state = "unverified_inputs"

    weighted = 0.0
    weight_used = 0.0
    for dim, weight in WEIGHTS.items():
        if dim in scores:
            weighted += scores[dim] * weight
            weight_used += weight
    overall = round(weighted / weight_used, 2) if weight_used else 0.0

    if mandate.get("status") in {"restricted","closed"} or opportunity.get("status") in {"restricted","rejected","closed"}:
        overall = min(overall, 20.0)
        neg.append("record status blocks introduction readiness")

    if overall >= 80:
        review = "priority_human_review"
    elif overall >= 60:
        review = "human_review_required"
    else:
        review = "below_review_threshold"

    return MatchResult(
        overall_score=overall,
        dimension_scores={k: round(v,2) for k,v in scores.items()},
        positive_factors=pos,
        negative_factors=neg,
        missing_information=sorted(set(missing)),
        verification_state=verification_state,
        review_requirement=review
    )
