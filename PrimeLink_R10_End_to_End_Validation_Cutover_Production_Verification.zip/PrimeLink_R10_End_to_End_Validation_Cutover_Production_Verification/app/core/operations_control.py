from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, Optional

@dataclass
class OperationalEvent:
    event_type: str
    severity: str
    summary: str
    owner: Optional[str] = None
    correlation_id: Optional[str] = None
    occurred_at: str = ""

    def __post_init__(self):
        if not self.occurred_at:
            self.occurred_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

def classify_health(database_ok: bool, critical_dependency_ok: bool = True) -> str:
    if not database_ok:
        return "unready"
    if not critical_dependency_ok:
        return "degraded"
    return "ready"

def privacy_request_action_allowed(identity_verified: bool, legal_hold: bool) -> bool:
    if not identity_verified:
        return False
    if legal_hold:
        return False
    return True

def recovery_assured(backup_success: bool, restore_success: bool,
                     integrity_ok: bool, application_ready: bool) -> bool:
    return all((backup_success, restore_success, integrity_ok, application_ready))
