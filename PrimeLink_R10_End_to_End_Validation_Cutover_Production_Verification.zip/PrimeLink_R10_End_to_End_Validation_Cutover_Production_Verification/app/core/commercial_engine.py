from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Optional, Dict, Any

TWOPLACES = Decimal("0.01")

def money(value) -> Decimal:
    try:
        return Decimal(str(value)).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValueError("invalid monetary amount") from exc

@dataclass
class FeeComputation:
    basis_amount: str
    rate_percent: str
    fee_amount: str
    currency: str
    state: str
    requires_invoice_approval: bool = True
    engine_version: str = "R7-commercial-1"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

def compute_percentage_fee(basis_amount, rate_percent, currency: str,
                           agreement_status: str, trigger_satisfied: bool) -> FeeComputation:
    basis = money(basis_amount)
    rate = Decimal(str(rate_percent))
    if basis < 0 or rate < 0:
        raise ValueError("negative commercial values are not allowed")
    if not currency or len(currency.strip()) != 3:
        raise ValueError("ISO currency code required")
    fee = (basis * rate / Decimal("100")).quantize(TWOPLACES, rounding=ROUND_HALF_UP)

    if agreement_status != "executed":
        state = "potential"
    elif not trigger_satisfied:
        state = "qualified"
    else:
        state = "earned"

    return FeeComputation(
        basis_amount=str(basis),
        rate_percent=str(rate.normalize()),
        fee_amount=str(fee),
        currency=currency.upper(),
        state=state
    )

def invoice_eligible(fee_event_status: str, approved: bool) -> bool:
    return fee_event_status == "earned" and approved is True

def reconciliation_state(invoice_amount, receipts_total) -> str:
    inv = money(invoice_amount)
    rec = money(receipts_total)
    if rec == Decimal("0.00"):
        return "unreconciled"
    if rec == inv:
        return "matched"
    return "exception"
