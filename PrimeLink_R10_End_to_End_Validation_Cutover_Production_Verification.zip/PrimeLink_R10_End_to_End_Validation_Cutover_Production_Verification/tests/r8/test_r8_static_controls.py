import json
from pathlib import Path
from app.core.operations_control import privacy_request_action_allowed, recovery_assured

def test_legal_hold_blocks_privacy_action():
    assert privacy_request_action_allowed(True,True) is False

def test_identity_required():
    assert privacy_request_action_allowed(False,False) is False

def test_backup_only_not_assured():
    assert recovery_assured(True,False,False,False) is False

def test_restore_chain_required():
    assert recovery_assured(True,True,True,True) is True

def test_control_plane_ui_present():
    assert 'id="control-plane"' in Path("app/static/index.html").read_text()
