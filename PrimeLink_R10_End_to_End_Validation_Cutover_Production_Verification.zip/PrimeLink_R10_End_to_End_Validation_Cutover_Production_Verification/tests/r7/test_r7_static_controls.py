import json
from pathlib import Path
from app.core.commercial_engine import compute_percentage_fee, invoice_eligible

def test_money_not_float():
    p=json.loads(Path("config/r7/revenue_policy.json").read_text())
    assert p["money"]["floating_point_for_money"] is False

def test_projected_not_collected():
    p=json.loads(Path("config/r7/commercial_contract.json").read_text())
    assert "never_treat_projected_revenue_as_collected_cash" in p["objectives"]

def test_draft_agreement_not_earned():
    r=compute_percentage_fee(1000000,1,"USD","draft",True)
    assert r.state=="potential"

def test_invoice_requires_earned_and_approved():
    assert invoice_eligible("earned",True)
    assert not invoice_eligible("earned",False)
    assert not invoice_eligible("qualified",True)

def test_commercial_ui_present():
    assert 'id="commercial"' in Path("app/static/index.html").read_text()
