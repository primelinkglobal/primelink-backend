import json
from pathlib import Path
def test_default_deny(): assert json.loads(Path("config/r3/rbac_policy.json").read_text())["default"]=="deny"
def test_bootstrap_disabled(): assert json.loads(Path("config/r3/authentication_policy.json").read_text())["production"]["allow_bootstrap_admin"] is False
def test_no_env_secret(): assert not Path(".env").exists()
def test_headers(): assert "Content-Security-Policy" in Path("app/core/security_headers.py").read_text()
