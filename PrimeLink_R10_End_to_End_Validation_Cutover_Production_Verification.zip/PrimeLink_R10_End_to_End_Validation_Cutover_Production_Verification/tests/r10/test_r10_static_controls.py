import json
from pathlib import Path

def test_target_state_explicit():
    p=json.loads(Path("config/r10/production_verification_contract.json").read_text())
    assert p["target_state"]=="PRIMELINK_REBUILD_PRODUCTION_VERIFIED"

def test_generated_package_not_verified():
    p=json.loads(Path("evidence/r10/PRODUCTION_CERTIFICATION_RECORD.json").read_text())
    assert p["production_verified"] is False

def test_cutover_has_rollback():
    p=json.loads(Path("config/r10/cutover_policy.json").read_text())
    assert p["strategy"]=="controlled cutover with rollback"
    assert len(p["rollback_triggers"])>0

def test_production_verification_ui_present():
    assert 'id="production-verification"' in Path("app/static/index.html").read_text()
