import json
from pathlib import Path
from app.core.matching_engine import score_match

def test_match_score_never_authorizes_introduction():
    p=json.loads(Path("config/r5/matching_policy.json").read_text())
    assert "match_score_never_authorizes_introduction" in p["hard_rules"]

def test_human_review_required():
    p=json.loads(Path("config/r5/matching_policy.json").read_text())
    assert "human_review_required_before_protected_introduction" in p["hard_rules"]

def test_matching_engine_explainable():
    r=score_match(
        {"geography":"dubai","sector_or_asset_type":"real estate","verification_state":"verified","status":"active"},
        {"geography":"dubai","sector_or_asset_type":"real estate","verification_state":"verified","status":"active"}
    )
    assert isinstance(r.dimension_scores, dict)
    assert r.verification_state=="verified_inputs"

def test_intelligence_ui_present():
    assert 'id="intelligence"' in Path("app/static/index.html").read_text()
