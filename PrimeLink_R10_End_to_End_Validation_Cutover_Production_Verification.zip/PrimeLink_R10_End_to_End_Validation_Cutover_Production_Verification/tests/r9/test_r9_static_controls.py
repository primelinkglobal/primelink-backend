import json
from pathlib import Path

def test_secrets_external():
    p=json.loads(Path("config/r9/environment_contract.json").read_text())
    assert p["required"]["DATABASE_URL"]["secret"] is True
    assert p["required"]["JWT_SECRET"]["secret"] is True

def test_bootstrap_admin_false():
    p=json.loads(Path("config/r9/environment_contract.json").read_text())
    assert p["required"]["ALLOW_BOOTSTRAP_ADMIN"]["value"]=="false"

def test_render_uses_r9_gates():
    t=Path("render.yaml").read_text()
    assert "scripts/r9/build_release.py" in t
    assert "scripts/r9/predeploy_gate.py" in t

def test_postdeploy_verifier_present():
    assert Path("scripts/r9/postdeploy_verify.py").exists()
