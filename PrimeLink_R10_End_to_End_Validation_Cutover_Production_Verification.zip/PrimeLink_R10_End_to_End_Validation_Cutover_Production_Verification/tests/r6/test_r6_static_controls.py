import json
from pathlib import Path
from app.core.connector_runtime import ConnectorRegistry

def test_unknown_connector_default_deny():
    p=json.loads(Path("config/r6/connector_registry.json").read_text())
    assert p["policy"]["unknown_connector"]=="deny"

def test_discovery_not_auto_verified():
    p=json.loads(Path("config/r6/connector_registry.json").read_text())
    assert p["policy"]["automatic_import_to_verified_state"] is False

def test_provenance_required():
    p=json.loads(Path("config/r6/provenance_policy.json").read_text())
    assert "source_reference" in p["required_fields"]

def test_static_connector_starts_unverified():
    r=ConnectorRegistry().run("static_example",{"geography":"dubai"})[0]
    assert r.verification_state=="discovered_unverified"

def test_discovery_ui_present():
    assert 'id="external-discovery"' in Path("app/static/index.html").read_text()
