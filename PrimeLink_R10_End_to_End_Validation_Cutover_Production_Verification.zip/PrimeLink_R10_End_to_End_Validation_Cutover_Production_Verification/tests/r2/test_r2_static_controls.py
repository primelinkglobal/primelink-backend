import json
from pathlib import Path

def test_r2_requires_postgresql():
    p=json.loads(Path("config/r2/schema_contract.json").read_text())
    assert p["database"]=="PostgreSQL"

def test_schema_changes_through_migrations():
    p=json.loads(Path("config/r2/schema_contract.json").read_text())
    assert "schema_changes_only_through_migrations" in p["principles"]

def test_no_embedded_env_file():
    assert not Path(".env").exists()

def test_render_uses_r2_migration_runner():
    t=Path("render.yaml").read_text()
    assert "python scripts/r2/run_migrations.py" in t
