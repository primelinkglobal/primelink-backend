import json
from pathlib import Path

def test_introduction_not_automatic():
    p=json.loads(Path("config/r4/domain_contract.json").read_text())
    assert "introduction_readiness_does_not_equal_automatic_introduction" in p["business_rules"]

def test_opportunity_lifecycle_has_verified_state():
    p=json.loads(Path("config/r4/lifecycle_policy.json").read_text())
    assert "verified" in p["opportunity_status"]

def test_data_quality_requires_source():
    p=json.loads(Path("config/r4/data_quality_policy.json").read_text())
    assert "source" in p["required_fields"]["opportunity"]

def test_business_core_ui_present():
    assert 'id="business-core"' in Path("app/static/index.html").read_text()
