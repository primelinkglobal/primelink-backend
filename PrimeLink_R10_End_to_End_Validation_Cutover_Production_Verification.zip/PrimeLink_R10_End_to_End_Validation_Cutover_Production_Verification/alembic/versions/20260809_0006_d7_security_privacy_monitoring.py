"""D7 security privacy monitoring
Revision ID: 20260809_0006
Revises: 20260809_0005
"""
from alembic import op
import sqlalchemy as sa
revision="20260809_0006"; down_revision="20260809_0005"; branch_labels=None; depends_on=None

def upgrade():
    op.create_table("privacy_requests",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("request_type",sa.String(60),nullable=False),
      sa.Column("subject_reference",sa.String(250),nullable=False),
      sa.Column("requester_email",sa.String(320)),
      sa.Column("jurisdiction",sa.String(120)),
      sa.Column("status",sa.String(60),nullable=False),
      sa.Column("identity_verification_state",sa.String(60),nullable=False),
      sa.Column("assigned_to",sa.String(320)),
      sa.Column("response_reference",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False),
      sa.Column("completed_at",sa.DateTime()))
    op.create_index("ix_privacy_requests_request_type","privacy_requests",["request_type"])
    op.create_index("ix_privacy_requests_subject_reference","privacy_requests",["subject_reference"])
    op.create_index("ix_privacy_requests_status","privacy_requests",["status"])

    op.create_table("retention_rules",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("record_class",sa.String(120),nullable=False),
      sa.Column("retention_days",sa.Integer()),
      sa.Column("deletion_enabled",sa.Boolean(),nullable=False),
      sa.Column("legal_hold_override",sa.Boolean(),nullable=False),
      sa.Column("owner_email",sa.String(320),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_retention_rules_record_class","retention_rules",["record_class"],unique=True)

    op.create_table("legal_holds",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("hold_reference",sa.String(120),nullable=False),
      sa.Column("scope",sa.Text(),nullable=False),
      sa.Column("reason",sa.Text(),nullable=False),
      sa.Column("owner_email",sa.String(320),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False),
      sa.Column("released_at",sa.DateTime()))
    op.create_index("ix_legal_holds_hold_reference","legal_holds",["hold_reference"],unique=True)
    op.create_index("ix_legal_holds_status","legal_holds",["status"])

    op.create_table("security_events",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("event_type",sa.String(100),nullable=False),
      sa.Column("severity",sa.String(30),nullable=False),
      sa.Column("actor_or_subject",sa.String(320)),
      sa.Column("source_ip",sa.String(80)),
      sa.Column("details_json",sa.Text()),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False),
      sa.Column("closed_at",sa.DateTime()))
    op.create_index("ix_security_events_event_type","security_events",["event_type"])
    op.create_index("ix_security_events_severity","security_events",["severity"])

    op.create_table("worker_heartbeats",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("worker_name",sa.String(120),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("last_seen_at",sa.DateTime(),nullable=False),
      sa.Column("details",sa.Text()))
    op.create_index("ix_worker_heartbeats_worker_name","worker_heartbeats",["worker_name"],unique=True)

    op.create_table("backup_status",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("backup_type",sa.String(80),nullable=False),
      sa.Column("backup_reference",sa.Text(),nullable=False),
      sa.Column("completed_at",sa.DateTime(),nullable=False),
      sa.Column("verified_restore",sa.Boolean(),nullable=False),
      sa.Column("verification_reference",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_backup_status_backup_type","backup_status",["backup_type"])

    op.create_table("audit_integrity_checkpoints",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("checkpoint_scope",sa.String(120),nullable=False),
      sa.Column("record_count",sa.Integer(),nullable=False),
      sa.Column("digest",sa.String(128),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))

def downgrade():
    for t in ["audit_integrity_checkpoints","backup_status","worker_heartbeats",
              "security_events","legal_holds","retention_rules","privacy_requests"]:
        op.drop_table(t)
