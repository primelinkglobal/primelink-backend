"""D5 external discovery
Revision ID: 20260809_0004
Revises: 20260809_0003
"""
from alembic import op
import sqlalchemy as sa
revision="20260809_0004"; down_revision="20260809_0003"; branch_labels=None; depends_on=None

def upgrade():
    op.create_table("discovery_sources",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("source_key",sa.String(120),nullable=False),
      sa.Column("name",sa.String(250),nullable=False),
      sa.Column("source_type",sa.String(80),nullable=False),
      sa.Column("purpose",sa.Text(),nullable=False),
      sa.Column("approved_scope",sa.Text(),nullable=False),
      sa.Column("terms_permission_status",sa.String(80),nullable=False),
      sa.Column("provenance_method",sa.String(120),nullable=False),
      sa.Column("enabled",sa.Boolean(),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("owner_email",sa.String(320),nullable=False),
      sa.Column("last_reviewed_at",sa.DateTime()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_discovery_sources_source_key","discovery_sources",["source_key"],unique=True)

    op.create_table("discovery_runs",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("mandate_id",sa.Integer(),sa.ForeignKey("mandates.id"),nullable=False),
      sa.Column("requested_by",sa.String(320),nullable=False),
      sa.Column("source_count",sa.Integer(),nullable=False),
      sa.Column("result_count",sa.Integer(),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("query_json",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_discovery_runs_mandate_id","discovery_runs",["mandate_id"])

    op.create_table("discovered_candidates",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("discovery_run_id",sa.Integer(),sa.ForeignKey("discovery_runs.id"),nullable=False),
      sa.Column("source_id",sa.Integer(),sa.ForeignKey("discovery_sources.id"),nullable=False),
      sa.Column("source_object_id",sa.String(250)),
      sa.Column("canonical_url",sa.Text()),
      sa.Column("title",sa.String(500),nullable=False),
      sa.Column("opportunity_type",sa.String(120)),
      sa.Column("geography",sa.String(120)),
      sa.Column("sector",sa.String(120)),
      sa.Column("value",sa.Float()),
      sa.Column("summary",sa.Text()),
      sa.Column("provenance_json",sa.Text(),nullable=False),
      sa.Column("retrieved_at",sa.DateTime(),nullable=False),
      sa.Column("verification_state",sa.String(60),nullable=False),
      sa.Column("review_state",sa.String(40),nullable=False),
      sa.Column("normalized_fingerprint",sa.String(128),nullable=False),
      sa.Column("duplicate_of_id",sa.Integer(),sa.ForeignKey("discovered_candidates.id")),
      sa.Column("imported_opportunity_id",sa.Integer(),sa.ForeignKey("opportunities.id")),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_discovered_candidates_discovery_run_id","discovered_candidates",["discovery_run_id"])
    op.create_index("ix_discovered_candidates_source_id","discovered_candidates",["source_id"])
    op.create_index("ix_discovered_candidates_normalized_fingerprint","discovered_candidates",["normalized_fingerprint"])

    op.create_table("connector_health_checks",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("source_id",sa.Integer(),sa.ForeignKey("discovery_sources.id"),nullable=False),
      sa.Column("reachable",sa.Boolean(),nullable=False),
      sa.Column("provenance_working",sa.Boolean(),nullable=False),
      sa.Column("scope_enforced",sa.Boolean(),nullable=False),
      sa.Column("latency_ms",sa.Float()),
      sa.Column("error_rate",sa.Float()),
      sa.Column("decision",sa.String(50),nullable=False),
      sa.Column("details",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_connector_health_checks_source_id","connector_health_checks",["source_id"])

    op.create_table("discovery_audit_events",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("actor",sa.String(320),nullable=False),
      sa.Column("action",sa.String(100),nullable=False),
      sa.Column("source_id",sa.Integer(),sa.ForeignKey("discovery_sources.id")),
      sa.Column("entity_type",sa.String(80),nullable=False),
      sa.Column("entity_id",sa.String(80),nullable=False),
      sa.Column("details_json",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_discovery_audit_events_action","discovery_audit_events",["action"])

def downgrade():
    for t in ["discovery_audit_events","connector_health_checks","discovered_candidates","discovery_runs","discovery_sources"]:
        op.drop_table(t)
