"""D3 opportunity CRM workflow deployment

Revision ID: 20260809_0002
Revises: 20260809_0001
"""
from alembic import op
import sqlalchemy as sa

revision="20260809_0002"
down_revision="20260809_0001"
branch_labels=None
depends_on=None

def upgrade():
    op.create_table("opportunity_activities",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("opportunity_id",sa.Integer(),sa.ForeignKey("opportunities.id"),nullable=False),
        sa.Column("actor_email",sa.String(320),nullable=False),
        sa.Column("activity_type",sa.String(80),nullable=False),
        sa.Column("from_state",sa.String(80)),
        sa.Column("to_state",sa.String(80)),
        sa.Column("note",sa.Text()),
        sa.Column("created_at",sa.DateTime(),nullable=False),
    )
    op.create_index("ix_opportunity_activities_opportunity_id","opportunity_activities",["opportunity_id"])

    op.create_table("crm_activities",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("participant_id",sa.Integer(),sa.ForeignKey("participants.id"),nullable=False),
        sa.Column("owner_email",sa.String(320),nullable=False),
        sa.Column("activity_type",sa.String(80),nullable=False),
        sa.Column("channel",sa.String(60)),
        sa.Column("subject",sa.String(250)),
        sa.Column("note",sa.Text()),
        sa.Column("next_action_at",sa.DateTime()),
        sa.Column("created_at",sa.DateTime(),nullable=False),
    )
    op.create_index("ix_crm_activities_participant_id","crm_activities",["participant_id"])
    op.create_index("ix_crm_activities_owner_email","crm_activities",["owner_email"])

    op.create_table("tasks",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("task_type",sa.String(80),nullable=False),
        sa.Column("title",sa.String(250),nullable=False),
        sa.Column("description",sa.Text()),
        sa.Column("owner_email",sa.String(320),nullable=False),
        sa.Column("entity_type",sa.String(80)),
        sa.Column("entity_id",sa.String(80)),
        sa.Column("status",sa.String(40),nullable=False),
        sa.Column("priority",sa.String(20),nullable=False),
        sa.Column("due_at",sa.DateTime()),
        sa.Column("created_at",sa.DateTime(),nullable=False),
        sa.Column("completed_at",sa.DateTime()),
    )
    op.create_index("ix_tasks_task_type","tasks",["task_type"])
    op.create_index("ix_tasks_owner_email","tasks",["owner_email"])
    op.create_index("ix_tasks_status","tasks",["status"])

    op.create_table("review_decisions",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("entity_type",sa.String(80),nullable=False),
        sa.Column("entity_id",sa.String(80),nullable=False),
        sa.Column("review_type",sa.String(80),nullable=False),
        sa.Column("reviewer_email",sa.String(320),nullable=False),
        sa.Column("decision",sa.String(60),nullable=False),
        sa.Column("reason",sa.Text()),
        sa.Column("created_at",sa.DateTime(),nullable=False),
    )
    op.create_index("ix_review_decisions_entity_type","review_decisions",["entity_type"])
    op.create_index("ix_review_decisions_entity_id","review_decisions",["entity_id"])
    op.create_index("ix_review_decisions_review_type","review_decisions",["review_type"])

    op.create_table("workflow_events",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("event_type",sa.String(100),nullable=False),
        sa.Column("entity_type",sa.String(80),nullable=False),
        sa.Column("entity_id",sa.String(80),nullable=False),
        sa.Column("payload_json",sa.Text()),
        sa.Column("status",sa.String(40),nullable=False),
        sa.Column("attempts",sa.Integer(),nullable=False),
        sa.Column("last_error",sa.Text()),
        sa.Column("created_at",sa.DateTime(),nullable=False),
        sa.Column("processed_at",sa.DateTime()),
    )
    op.create_index("ix_workflow_events_event_type","workflow_events",["event_type"])
    op.create_index("ix_workflow_events_status","workflow_events",["status"])

    op.create_table("notification_outbox",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("recipient",sa.String(320),nullable=False),
        sa.Column("channel",sa.String(40),nullable=False),
        sa.Column("template_key",sa.String(100),nullable=False),
        sa.Column("subject",sa.String(250)),
        sa.Column("body",sa.Text(),nullable=False),
        sa.Column("status",sa.String(40),nullable=False),
        sa.Column("attempts",sa.Integer(),nullable=False),
        sa.Column("last_error",sa.Text()),
        sa.Column("created_at",sa.DateTime(),nullable=False),
        sa.Column("sent_at",sa.DateTime()),
    )
    op.create_index("ix_notification_outbox_recipient","notification_outbox",["recipient"])
    op.create_index("ix_notification_outbox_status","notification_outbox",["status"])

    op.create_table("introduction_preparations",
        sa.Column("id",sa.Integer(),primary_key=True),
        sa.Column("match_id",sa.Integer(),sa.ForeignKey("match_records.id"),nullable=False),
        sa.Column("relationship_owner_email",sa.String(320),nullable=False),
        sa.Column("human_review_complete",sa.Boolean(),nullable=False),
        sa.Column("verification_complete",sa.Boolean(),nullable=False),
        sa.Column("compliance_gate_passed",sa.Boolean(),nullable=False),
        sa.Column("counterparty_consent_complete",sa.Boolean(),nullable=False),
        sa.Column("status",sa.String(50),nullable=False),
        sa.Column("created_at",sa.DateTime(),nullable=False),
        sa.Column("updated_at",sa.DateTime(),nullable=False),
    )
    op.create_index("ix_introduction_preparations_match_id","introduction_preparations",["match_id"])

def downgrade():
    for table in ["introduction_preparations","notification_outbox","workflow_events",
                  "review_decisions","tasks","crm_activities","opportunity_activities"]:
        op.drop_table(table)
