"""D2 production baseline

Revision ID: 20260809_0001
Revises:
"""
from alembic import op
import sqlalchemy as sa

revision = "20260809_0001"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("users",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("password_hash", sa.String(500), nullable=False),
        sa.Column("role", sa.String(50), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_users_email","users",["email"],unique=True)

    op.create_table("participants",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("participant_type", sa.String(80), nullable=False),
        sa.Column("name", sa.String(250), nullable=False),
        sa.Column("organization", sa.String(250)),
        sa.Column("geography", sa.String(120)),
        sa.Column("verification_state", sa.String(60), nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_participants_participant_type","participants",["participant_type"])
    op.create_index("ix_participants_name","participants",["name"])

    op.create_table("mandates",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("participant_id", sa.Integer(), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("objective", sa.String(250), nullable=False),
        sa.Column("geography", sa.String(120), nullable=False),
        sa.Column("sector", sa.String(120), nullable=False),
        sa.Column("ticket_min", sa.Float()),
        sa.Column("ticket_max", sa.Float()),
        sa.Column("constraints", sa.Text()),
        sa.Column("freshness", sa.String(30), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )

    op.create_table("opportunities",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("title", sa.String(250), nullable=False),
        sa.Column("opportunity_type", sa.String(120), nullable=False),
        sa.Column("geography", sa.String(120), nullable=False),
        sa.Column("sector", sa.String(120), nullable=False),
        sa.Column("value", sa.Float()),
        sa.Column("stage", sa.String(80), nullable=False),
        sa.Column("source", sa.String(250), nullable=False),
        sa.Column("provenance", sa.Text()),
        sa.Column("verification_state", sa.String(60), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )

    op.create_table("relationships",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("participant_id", sa.Integer(), sa.ForeignKey("participants.id"), nullable=False),
        sa.Column("owner_email", sa.String(320), nullable=False),
        sa.Column("status", sa.String(50), nullable=False),
        sa.Column("notes", sa.Text()),
        sa.Column("last_interaction", sa.DateTime()),
    )

    op.create_table("match_records",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("mandate_id", sa.Integer(), sa.ForeignKey("mandates.id"), nullable=False),
        sa.Column("opportunity_id", sa.Integer(), sa.ForeignKey("opportunities.id"), nullable=False),
        sa.Column("score", sa.Float(), nullable=False),
        sa.Column("explanation", sa.Text(), nullable=False),
        sa.Column("human_review_state", sa.String(50), nullable=False),
        sa.Column("introduction_eligible", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )

    op.create_table("commercial_cases",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("opportunity_id", sa.Integer(), sa.ForeignKey("opportunities.id")),
        sa.Column("agreement_reference", sa.String(250)),
        sa.Column("commercial_state", sa.String(60), nullable=False),
        sa.Column("fee_trigger", sa.String(250)),
        sa.Column("currency", sa.String(10)),
        sa.Column("amount_estimate", sa.Float()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )

    op.create_table("audit_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("actor", sa.String(320), nullable=False),
        sa.Column("action", sa.String(120), nullable=False),
        sa.Column("entity_type", sa.String(80), nullable=False),
        sa.Column("entity_id", sa.String(80), nullable=False),
        sa.Column("details", sa.Text()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )

    op.create_table("auth_tokens",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("token_hash", sa.String(128), nullable=False),
        sa.Column("token_type", sa.String(40), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("used_at", sa.DateTime()),
        sa.Column("revoked", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_auth_tokens_user_id","auth_tokens",["user_id"])
    op.create_index("ix_auth_tokens_token_hash","auth_tokens",["token_hash"],unique=True)
    op.create_index("ix_auth_tokens_token_type","auth_tokens",["token_type"])

    op.create_table("login_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("success", sa.Boolean(), nullable=False),
        sa.Column("ip_address", sa.String(80)),
        sa.Column("user_agent", sa.String(500)),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_login_events_email","login_events",["email"])

def downgrade():
    for table in ["login_events","auth_tokens","audit_events","commercial_cases","match_records",
                  "relationships","opportunities","mandates","participants","users"]:
        op.drop_table(table)
