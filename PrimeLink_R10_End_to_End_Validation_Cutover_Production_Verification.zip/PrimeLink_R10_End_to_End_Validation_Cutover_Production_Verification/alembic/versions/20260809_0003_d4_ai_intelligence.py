"""D4 AI intelligence
Revision ID: 20260809_0003
Revises: 20260809_0002
"""
from alembic import op
import sqlalchemy as sa
revision="20260809_0003"; down_revision="20260809_0002"; branch_labels=None; depends_on=None
def upgrade():
    op.create_table("ai_model_versions",
      sa.Column("id",sa.Integer(),primary_key=True),sa.Column("provider",sa.String(80),nullable=False),
      sa.Column("model_name",sa.String(160),nullable=False),sa.Column("version_label",sa.String(120),nullable=False),
      sa.Column("prompt_version",sa.String(120),nullable=False),sa.Column("active",sa.Boolean(),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_ai_model_versions_version_label","ai_model_versions",["version_label"])
    op.create_table("ai_match_runs",
      sa.Column("id",sa.Integer(),primary_key=True),sa.Column("mandate_id",sa.Integer(),sa.ForeignKey("mandates.id"),nullable=False),
      sa.Column("model_version",sa.String(120),nullable=False),sa.Column("candidate_count",sa.Integer(),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_ai_match_runs_mandate_id","ai_match_runs",["mandate_id"])
    op.create_table("ai_match_candidates",
      sa.Column("id",sa.Integer(),primary_key=True),sa.Column("run_id",sa.Integer(),sa.ForeignKey("ai_match_runs.id"),nullable=False),
      sa.Column("opportunity_id",sa.Integer(),sa.ForeignKey("opportunities.id"),nullable=False),
      sa.Column("structured_score",sa.Float(),nullable=False),sa.Column("semantic_score",sa.Float(),nullable=False),
      sa.Column("final_score",sa.Float(),nullable=False),sa.Column("explanation",sa.Text(),nullable=False),
      sa.Column("evidence_json",sa.Text()),sa.Column("human_review_state",sa.String(40),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_ai_match_candidates_run_id","ai_match_candidates",["run_id"])
    op.create_index("ix_ai_match_candidates_opportunity_id","ai_match_candidates",["opportunity_id"])
    op.create_index("ix_ai_match_candidates_final_score","ai_match_candidates",["final_score"])
    op.create_table("ai_evaluations",
      sa.Column("id",sa.Integer(),primary_key=True),sa.Column("run_id",sa.Integer(),sa.ForeignKey("ai_match_runs.id")),
      sa.Column("metric_name",sa.String(100),nullable=False),sa.Column("metric_value",sa.Float(),nullable=False),
      sa.Column("dataset_version",sa.String(120),nullable=False),sa.Column("notes",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_ai_evaluations_metric_name","ai_evaluations",["metric_name"])
    op.create_table("ai_audit_events",
      sa.Column("id",sa.Integer(),primary_key=True),sa.Column("actor",sa.String(320),nullable=False),
      sa.Column("action",sa.String(100),nullable=False),sa.Column("model_version",sa.String(120)),
      sa.Column("entity_type",sa.String(80),nullable=False),sa.Column("entity_id",sa.String(80),nullable=False),
      sa.Column("details_json",sa.Text()),sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_ai_audit_events_action","ai_audit_events",["action"])
def downgrade():
    for t in ["ai_audit_events","ai_evaluations","ai_match_candidates","ai_match_runs","ai_model_versions"]: op.drop_table(t)
