"""D6 commercial partner investor activation
Revision ID: 20260809_0005
Revises: 20260809_0004
"""
from alembic import op
import sqlalchemy as sa
revision="20260809_0005"; down_revision="20260809_0004"; branch_labels=None; depends_on=None

def upgrade():
    op.create_table("onboarding_applications",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("participant_type",sa.String(80),nullable=False),
      sa.Column("applicant_name",sa.String(250),nullable=False),
      sa.Column("organization",sa.String(250)),
      sa.Column("email",sa.String(320),nullable=False),
      sa.Column("geography",sa.String(120)),
      sa.Column("sectors",sa.Text()),
      sa.Column("source",sa.String(120)),
      sa.Column("profile_json",sa.Text()),
      sa.Column("terms_accepted",sa.Boolean(),nullable=False),
      sa.Column("verification_required",sa.Boolean(),nullable=False),
      sa.Column("verification_state",sa.String(60),nullable=False),
      sa.Column("review_state",sa.String(60),nullable=False),
      sa.Column("reviewer_email",sa.String(320)),
      sa.Column("review_reason",sa.Text()),
      sa.Column("participant_id",sa.Integer(),sa.ForeignKey("participants.id")),
      sa.Column("created_at",sa.DateTime(),nullable=False),
      sa.Column("reviewed_at",sa.DateTime()))
    op.create_index("ix_onboarding_applications_participant_type","onboarding_applications",["participant_type"])
    op.create_index("ix_onboarding_applications_email","onboarding_applications",["email"])

    op.create_table("agreement_records",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("agreement_type",sa.String(100),nullable=False),
      sa.Column("agreement_reference",sa.String(250),nullable=False),
      sa.Column("party_a",sa.String(250),nullable=False),
      sa.Column("party_b",sa.String(250),nullable=False),
      sa.Column("participant_id",sa.Integer(),sa.ForeignKey("participants.id")),
      sa.Column("effective_date",sa.DateTime()),
      sa.Column("expiry_date",sa.DateTime()),
      sa.Column("fee_mechanism",sa.String(120)),
      sa.Column("fee_trigger",sa.Text()),
      sa.Column("payment_terms",sa.Text()),
      sa.Column("referral_allocation_terms",sa.Text()),
      sa.Column("version_label",sa.String(80),nullable=False),
      sa.Column("status",sa.String(40),nullable=False),
      sa.Column("record_location",sa.Text()),
      sa.Column("owner_email",sa.String(320),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_agreement_records_agreement_type","agreement_records",["agreement_type"])
    op.create_index("ix_agreement_records_agreement_reference","agreement_records",["agreement_reference"],unique=True)
    op.create_index("ix_agreement_records_status","agreement_records",["status"])

    op.create_table("relationship_claim_checks",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("preparation_id",sa.Integer(),sa.ForeignKey("introduction_preparations.id"),nullable=False),
      sa.Column("party_a_reference",sa.String(250),nullable=False),
      sa.Column("party_b_reference",sa.String(250),nullable=False),
      sa.Column("checked_by",sa.String(320),nullable=False),
      sa.Column("prior_relationship_found",sa.Boolean(),nullable=False),
      sa.Column("claimant_reference",sa.String(250)),
      sa.Column("evidence_reference",sa.Text()),
      sa.Column("decision",sa.String(60),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_relationship_claim_checks_preparation_id","relationship_claim_checks",["preparation_id"])

    op.create_table("protected_introductions",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("preparation_id",sa.Integer(),sa.ForeignKey("introduction_preparations.id"),nullable=False),
      sa.Column("match_id",sa.Integer(),sa.ForeignKey("match_records.id"),nullable=False),
      sa.Column("agreement_id",sa.Integer(),sa.ForeignKey("agreement_records.id")),
      sa.Column("party_a_reference",sa.String(250),nullable=False),
      sa.Column("party_b_reference",sa.String(250),nullable=False),
      sa.Column("relationship_owner_email",sa.String(320),nullable=False),
      sa.Column("authorized_by",sa.String(320),nullable=False),
      sa.Column("channel",sa.String(60),nullable=False),
      sa.Column("introduction_reference",sa.Text()),
      sa.Column("prior_relationship_checked",sa.Boolean(),nullable=False),
      sa.Column("compliance_gate_passed",sa.Boolean(),nullable=False),
      sa.Column("status",sa.String(50),nullable=False),
      sa.Column("introduced_at",sa.DateTime()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_protected_introductions_preparation_id","protected_introductions",["preparation_id"])
    op.create_index("ix_protected_introductions_match_id","protected_introductions",["match_id"])

    op.create_table("prior_relationship_checks",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("introduction_id",sa.Integer(),sa.ForeignKey("protected_introductions.id"),nullable=False),
      sa.Column("checked_by",sa.String(320),nullable=False),
      sa.Column("prior_relationship_found",sa.Boolean(),nullable=False),
      sa.Column("prior_claimant",sa.String(250)),
      sa.Column("evidence_reference",sa.Text()),
      sa.Column("decision",sa.String(60),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_prior_relationship_checks_introduction_id","prior_relationship_checks",["introduction_id"])

    op.create_table("fee_events",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("commercial_case_id",sa.Integer(),sa.ForeignKey("commercial_cases.id"),nullable=False),
      sa.Column("agreement_id",sa.Integer(),sa.ForeignKey("agreement_records.id"),nullable=False),
      sa.Column("introduction_id",sa.Integer(),sa.ForeignKey("protected_introductions.id")),
      sa.Column("trigger_type",sa.String(120),nullable=False),
      sa.Column("trigger_date",sa.DateTime()),
      sa.Column("event_evidence",sa.Text()),
      sa.Column("calculation_basis",sa.Text()),
      sa.Column("currency",sa.String(10)),
      sa.Column("amount",sa.Float()),
      sa.Column("duplicate_claim",sa.Boolean(),nullable=False),
      sa.Column("approval_state",sa.String(60),nullable=False),
      sa.Column("status",sa.String(60),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_fee_events_commercial_case_id","fee_events",["commercial_case_id"])
    op.create_index("ix_fee_events_agreement_id","fee_events",["agreement_id"])

    op.create_table("invoice_records",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("fee_event_id",sa.Integer(),sa.ForeignKey("fee_events.id"),nullable=False),
      sa.Column("invoice_reference",sa.String(120),nullable=False),
      sa.Column("bill_to",sa.String(250),nullable=False),
      sa.Column("currency",sa.String(10),nullable=False),
      sa.Column("amount",sa.Float(),nullable=False),
      sa.Column("due_date",sa.DateTime()),
      sa.Column("status",sa.String(50),nullable=False),
      sa.Column("paid_amount",sa.Float(),nullable=False),
      sa.Column("record_location",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_invoice_records_fee_event_id","invoice_records",["fee_event_id"])
    op.create_index("ix_invoice_records_invoice_reference","invoice_records",["invoice_reference"],unique=True)

    op.create_table("collection_records",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("invoice_id",sa.Integer(),sa.ForeignKey("invoice_records.id"),nullable=False),
      sa.Column("payer",sa.String(250),nullable=False),
      sa.Column("currency",sa.String(10),nullable=False),
      sa.Column("amount",sa.Float(),nullable=False),
      sa.Column("payment_reference",sa.String(250),nullable=False),
      sa.Column("reconciled",sa.Boolean(),nullable=False),
      sa.Column("status",sa.String(50),nullable=False),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_collection_records_invoice_id","collection_records",["invoice_id"])
    op.create_index("ix_collection_records_payment_reference","collection_records",["payment_reference"],unique=True)

    op.create_table("referral_allocations",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("fee_event_id",sa.Integer(),sa.ForeignKey("fee_events.id"),nullable=False),
      sa.Column("partner_participant_id",sa.Integer(),sa.ForeignKey("participants.id"),nullable=False),
      sa.Column("governing_agreement_id",sa.Integer(),sa.ForeignKey("agreement_records.id"),nullable=False),
      sa.Column("calculation_basis",sa.Text(),nullable=False),
      sa.Column("currency",sa.String(10),nullable=False),
      sa.Column("amount",sa.Float(),nullable=False),
      sa.Column("approval_state",sa.String(60),nullable=False),
      sa.Column("payment_state",sa.String(60),nullable=False),
      sa.Column("evidence_reference",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_referral_allocations_fee_event_id","referral_allocations",["fee_event_id"])
    op.create_index("ix_referral_allocations_partner_participant_id","referral_allocations",["partner_participant_id"])

    op.create_table("commercial_audit_events",
      sa.Column("id",sa.Integer(),primary_key=True),
      sa.Column("actor",sa.String(320),nullable=False),
      sa.Column("action",sa.String(100),nullable=False),
      sa.Column("entity_type",sa.String(80),nullable=False),
      sa.Column("entity_id",sa.String(80),nullable=False),
      sa.Column("details_json",sa.Text()),
      sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_commercial_audit_events_action","commercial_audit_events",["action"])

def downgrade():
    for t in [
        "commercial_audit_events","referral_allocations","collection_records","invoice_records",
        "fee_events","prior_relationship_checks","protected_introductions","relationship_claim_checks",
        "agreement_records","onboarding_applications"
    ]:
        op.drop_table(t)
